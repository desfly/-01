import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from firmware_fixture import make_full_flash, make_mtd5


class FullFlashReconstructionTests(unittest.TestCase):
    def test_reconstructs_exact_16m_image_and_matches_report(self):
        with tempfile.TemporaryDirectory() as td_raw:
            td = pathlib.Path(td_raw)
            full = make_full_flash()
            uboot, firmware, art = full[:0x20000], full[0x20000:0xFF0000], full[0xFF0000:]
            import hashlib
            (td / "uboot.bin").write_bytes(uboot)
            (td / "firmware.bin").write_bytes(firmware)
            (td / "art.bin").write_bytes(art)
            backup = {
                "operation": "read-only backup",
                "writes_to_flash": False,
                "pass": True,
                "uboot": {"size": len(uboot), "sha256": hashlib.sha256(uboot).hexdigest()},
                "art": {"size": len(art), "sha256": hashlib.sha256(art).hexdigest()},
            }
            (td / "backup.json").write_text(json.dumps(backup))
            proc = subprocess.run([
                sys.executable, str(ROOT / "tools/reconstruct-stock-fullflash.py"),
                "--uboot", str(td / "uboot.bin"), "--firmware", str(td / "firmware.bin"),
                "--art", str(td / "art.bin"), "--backup-report", str(td / "backup.json"),
                "--out", str(td / "full.bin"), "--report", str(td / "report.json"),
            ], capture_output=True, text=True)
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            self.assertEqual((td / "full.bin").read_bytes(), full)
            report = json.loads((td / "report.json").read_text())
            self.assertTrue(report["pass"])
            self.assertTrue(all(report["backup_report_match"].values()))
            self.assertTrue(report["device_specific"])

    def test_refuses_wrong_partition_size(self):
        with tempfile.TemporaryDirectory() as td_raw:
            td = pathlib.Path(td_raw)
            full = make_full_flash()
            (td / "uboot.bin").write_bytes(full[:0x20000 - 1])
            (td / "firmware.bin").write_bytes(make_mtd5())
            (td / "art.bin").write_bytes(full[0xFF0000:])
            proc = subprocess.run([
                sys.executable, str(ROOT / "tools/reconstruct-stock-fullflash.py"),
                "--uboot", str(td / "uboot.bin"), "--firmware", str(td / "firmware.bin"),
                "--art", str(td / "art.bin"), "--out", str(td / "full.bin"),
                "--report", str(td / "report.json"),
            ], capture_output=True, text=True)
            self.assertNotEqual(proc.returncode, 0)
            self.assertFalse((td / "full.bin").exists())
            self.assertIn("uboot_size_mismatch", json.loads((td / "report.json").read_text())["blockers"])


if __name__ == "__main__":
    unittest.main()
