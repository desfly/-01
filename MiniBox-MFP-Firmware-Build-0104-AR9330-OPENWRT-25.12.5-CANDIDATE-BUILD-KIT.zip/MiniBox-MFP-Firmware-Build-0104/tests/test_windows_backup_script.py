import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class WindowsBackupScriptTests(unittest.TestCase):
    def test_script_is_read_only_and_checks_exact_sizes(self):
        text = (ROOT / "tools/windows/Get-MiniBox-CriticalBackups.ps1").read_text()
        self.assertIn("dd if=/dev/mtd0", text)
        self.assertIn("dd if=/dev/mtd4", text)
        self.assertNotIn("mtd write", text)
        self.assertNotIn("of=/dev/mtd", text)
        self.assertIn("131072", text)
        self.assertIn("65536", text)
        self.assertIn("Get-FileHash -Algorithm SHA256", text)
        self.assertIn("writes_to_flash = $false", text)


if __name__ == "__main__":
    unittest.main()
