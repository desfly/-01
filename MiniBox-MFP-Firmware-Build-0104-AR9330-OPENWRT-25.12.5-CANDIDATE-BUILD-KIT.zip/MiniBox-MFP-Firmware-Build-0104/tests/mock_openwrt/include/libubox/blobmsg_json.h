#ifndef MOCK_BLOBMSG_H
#define MOCK_BLOBMSG_H
#include <stddef.h>
#include <stdint.h>
struct blob_attr { int unused; };
struct blob_buf { void *head; };
struct blobmsg_policy { const char *name; int type; };
#define BLOBMSG_TYPE_STRING 1
void blob_buf_init(struct blob_buf *, int);
void blobmsg_add_string(struct blob_buf *, const char *, const char *);
void blobmsg_add_u8(struct blob_buf *, const char *, uint8_t);
void blobmsg_add_u32(struct blob_buf *, const char *, uint32_t);
void blobmsg_add_u64(struct blob_buf *, const char *, uint64_t);
void blobmsg_parse(const struct blobmsg_policy *, int, struct blob_attr **, const void *, size_t);
const char *blobmsg_get_string(const struct blob_attr *);
static inline void *blob_data(struct blob_attr *a) { return a; }
static inline size_t blob_len(struct blob_attr *a) { (void)a; return 0; }
#endif
