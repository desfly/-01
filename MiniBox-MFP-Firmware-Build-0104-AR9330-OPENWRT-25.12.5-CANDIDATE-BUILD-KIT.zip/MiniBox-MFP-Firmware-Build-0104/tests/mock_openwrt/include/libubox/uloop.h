#ifndef MOCK_ULOOP_H
#define MOCK_ULOOP_H
#include <stddef.h>
struct uloop_fd { int fd; void (*cb)(struct uloop_fd *, unsigned); };
struct uloop_timeout { void (*cb)(struct uloop_timeout *); };
#define ULOOP_READ 1u
#define ULOOP_EDGE_TRIGGER 2u
#define container_of(ptr, type, member) ((type *)((char *)(ptr) - offsetof(type, member)))
int uloop_init(void); void uloop_done(void); void uloop_run(void);
int uloop_fd_add(struct uloop_fd *, unsigned); int uloop_fd_delete(struct uloop_fd *);
int uloop_timeout_set(struct uloop_timeout *, int); int uloop_timeout_cancel(struct uloop_timeout *);
#endif
