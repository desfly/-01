#ifndef MOCK_UCI_H
#define MOCK_UCI_H
struct uci_context; struct uci_package;
#define UCI_OK 0
struct uci_context *uci_alloc_context(void);
void uci_free_context(struct uci_context *);
int uci_load(struct uci_context *, const char *, struct uci_package **);
void uci_unload(struct uci_context *, struct uci_package *);
#endif
