#ifndef MOCK_UBUS_H
#define MOCK_UBUS_H
#include <stddef.h>
#include "libubox/uloop.h"
struct blob_attr; struct blobmsg_policy;
struct ubus_context { int unused; };
struct ubus_object { const char *name; const struct ubus_object_type *type; const struct ubus_method *methods; size_t n_methods; };
struct ubus_object_type { const char *name; };
struct ubus_request_data { int unused; };
typedef int (*ubus_handler_t)(struct ubus_context *, struct ubus_object *, struct ubus_request_data *, const char *, struct blob_attr *);
struct ubus_method { const char *name; ubus_handler_t handler; const struct blobmsg_policy *policy; size_t n_policy; };
#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))
#define UBUS_METHOD_NOARG(n,h) { .name=(n), .handler=(h), .policy=NULL, .n_policy=0 }
#define UBUS_METHOD(n,h,p) { .name=(n), .handler=(h), .policy=(p), .n_policy=ARRAY_SIZE(p) }
#define UBUS_OBJECT_TYPE(n,m) { .name=(n) }
#define UBUS_STATUS_INVALID_ARGUMENT 2
#define UBUS_STATUS_UNKNOWN_ERROR 1
#define UBUS_STATUS_PERMISSION_DENIED 6
struct ubus_context *ubus_connect(const char *);
void ubus_free(struct ubus_context *);
void ubus_add_uloop(struct ubus_context *);
int ubus_add_object(struct ubus_context *, struct ubus_object *);
int ubus_send_reply(struct ubus_context *, struct ubus_request_data *, void *);
#endif
