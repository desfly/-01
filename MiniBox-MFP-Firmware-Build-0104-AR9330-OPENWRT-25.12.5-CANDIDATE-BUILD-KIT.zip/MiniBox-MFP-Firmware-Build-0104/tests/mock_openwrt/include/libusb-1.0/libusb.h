#ifndef MOCK_LIBUSB_H
#define MOCK_LIBUSB_H
#include <stdint.h>
#include <sys/types.h>
typedef struct libusb_context libusb_context;
typedef struct libusb_device libusb_device;
typedef struct libusb_device_handle libusb_device_handle;
struct libusb_device_descriptor { uint16_t idVendor, idProduct; };
struct libusb_endpoint_descriptor { uint8_t bEndpointAddress, bmAttributes; };
struct libusb_interface_descriptor { uint8_t bInterfaceNumber, bAlternateSetting, bInterfaceClass, bNumEndpoints; const struct libusb_endpoint_descriptor *endpoint; };
struct libusb_interface { const struct libusb_interface_descriptor *altsetting; int num_altsetting; };
struct libusb_config_descriptor { uint8_t bNumInterfaces; const struct libusb_interface *interface; };
#define LIBUSB_TRANSFER_TYPE_MASK 0x3
#define LIBUSB_TRANSFER_TYPE_BULK 2
#define LIBUSB_ENDPOINT_DIR_MASK 0x80
#define LIBUSB_ENDPOINT_OUT 0
#define LIBUSB_CLASS_PRINTER 7
int libusb_init(libusb_context **);
void libusb_exit(libusb_context *);
ssize_t libusb_get_device_list(libusb_context *, libusb_device ***);
void libusb_free_device_list(libusb_device **, int);
int libusb_get_device_descriptor(libusb_device *, struct libusb_device_descriptor *);
int libusb_open(libusb_device *, libusb_device_handle **);
void libusb_close(libusb_device_handle *);
int libusb_get_active_config_descriptor(libusb_device *, struct libusb_config_descriptor **);
int libusb_get_config_descriptor(libusb_device *, uint8_t, struct libusb_config_descriptor **);
void libusb_free_config_descriptor(struct libusb_config_descriptor *);
int libusb_kernel_driver_active(libusb_device_handle *, int);
int libusb_claim_interface(libusb_device_handle *, int);
int libusb_set_interface_alt_setting(libusb_device_handle *, int, int);
int libusb_release_interface(libusb_device_handle *, int);
int libusb_bulk_transfer(libusb_device_handle *, unsigned char, unsigned char *, int, int *, unsigned int);
#endif
