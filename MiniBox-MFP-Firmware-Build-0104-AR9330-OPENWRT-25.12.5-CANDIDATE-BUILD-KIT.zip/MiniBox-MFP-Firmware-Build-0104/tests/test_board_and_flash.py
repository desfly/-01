import importlib.util, pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('flash',ROOT/'emulator/flash16_emulator.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
class BoardFlashTests(unittest.TestCase):
    def test_layout_is_exactly_16mib(self):
        self.assertEqual(m.ART_OFF+m.ART_SIZE,m.FLASH_SIZE)
        self.assertEqual(m.FIRMWARE_OFF+m.FIRMWARE_SIZE,m.ART_OFF)
    def test_protected_regions_survive(self):
        f=m.Flash16(); u=bytes(f.data[:m.UBOOT_SIZE]); a=bytes(f.data[m.ART_OFF:]); result=f.apply_sysupgrade(b'FIRMWARE'*1000)
        self.assertTrue(result.accepted); self.assertEqual(u,bytes(f.data[:m.UBOOT_SIZE])); self.assertEqual(a,bytes(f.data[m.ART_OFF:]))
    def test_oversize_is_rejected(self):
        self.assertFalse(m.Flash16().apply_sysupgrade(b'x'*(m.FIRMWARE_SIZE+1)).accepted)
    def test_dts_facts(self):
        d=(ROOT/'board-port/target/linux/ath79/dts/ar9330_gainstrong_minibox-v1.dts').read_text()
        for token in ['#include "ar9330.dtsi"','"qca,ar9330"','gpio 1 GPIO_ACTIVE_LOW','gpio 11 GPIO_ACTIVE_HIGH','macaddr@1fc00','partition@ff0000','reg = <0x1000 0x440>','dr_mode = "host"','mac-address-increment = <1>','mac-address-increment = <(-1)>']:
            self.assertIn(token,d)
        self.assertLess(d.index('&eth1 {'), d.index('gmac-config'))
        self.assertNotIn('compatible = "syscon", "simple-mfd";', d)
if __name__=='__main__': unittest.main()
