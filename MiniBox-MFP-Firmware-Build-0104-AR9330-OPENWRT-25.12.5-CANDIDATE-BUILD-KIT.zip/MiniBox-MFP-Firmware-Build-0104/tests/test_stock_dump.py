import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from firmware_fixture import make_full_flash, make_mtd5


class StockDumpTests(unittest.TestCase):
    def test_valid_mtd5_passes_and_reports_missing_external_regions_as_warnings(self):
        with tempfile.TemporaryDirectory() as td:
            path = pathlib.Path(td) / "firmware.bin"
            path.write_bytes(make_mtd5())
            proc = subprocess.run(
                [sys.executable, str(ROOT / "tools/verify_stock_dump.py"), str(path), "--json"],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            report = json.loads(proc.stdout)
            self.assertEqual(report["dump_type"], "mtd5")
            self.assertTrue(report["pass"])
            self.assertIn("u_boot_not_present_in_mtd5_dump", report["warnings"])
            self.assertEqual(report["sections"]["rootfs"]["tree_entries"], 1)

    def test_valid_full_flash_passes_with_mac_and_art(self):
        with tempfile.TemporaryDirectory() as td:
            path = pathlib.Path(td) / "flash.bin"
            path.write_bytes(make_full_flash())
            proc = subprocess.run(
                [sys.executable, str(ROOT / "tools/verify_stock_dump.py"), str(path), "--json"],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            report = json.loads(proc.stdout)
            self.assertEqual(report["dump_type"], "full-flash")
            self.assertTrue(report["checks"]["base_mac_valid"])
            self.assertTrue(report["checks"]["wifi_calibration_nonempty"])

    def test_short_dump_is_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            path = pathlib.Path(td) / "bad.bin"
            path.write_bytes(b"x" * 1024)
            proc = subprocess.run(
                [sys.executable, str(ROOT / "tools/verify_stock_dump.py"), str(path), "--json"],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 3)
            self.assertIn("unsupported_dump_size", proc.stdout)


if __name__ == "__main__":
    unittest.main()
