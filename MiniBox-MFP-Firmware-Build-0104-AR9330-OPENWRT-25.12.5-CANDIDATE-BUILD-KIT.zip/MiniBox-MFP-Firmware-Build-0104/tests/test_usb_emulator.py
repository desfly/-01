import binascii, pathlib, re, subprocess, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class UsbEmulatorTests(unittest.TestCase):
    def test_print_transaction(self):
        binary=ROOT/'.host-build/miniboxd-host'; self.assertTrue(binary.exists())
        with tempfile.TemporaryDirectory() as td:
            td=pathlib.Path(td); out=td/'out'; page=td/'test.pcl'; page.write_bytes(b'\x1bEHost emulator PCL test\n\x0c')
            proc=subprocess.Popen([sys.executable,str(ROOT/'emulator/usb_mfp_emulator.py'),'--outdir',str(out),'--once'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            line=proc.stdout.readline().strip(); self.assertRegex(line,r'^LISTEN \d+$'); port=int(line.split()[1])
            run=subprocess.run([str(binary),'--print',str(page),'--tcp',f'127.0.0.1:{port}'],capture_output=True,text=True,timeout=10)
            self.assertEqual(run.returncode,0,run.stderr); self.assertEqual(proc.wait(timeout=10),0)
            proc.stdout.close(); proc.stderr.close()
            crc=binascii.crc32(page.read_bytes())&0xffffffff
            self.assertEqual((out/f'job-{crc:08x}.pcl').read_bytes(),page.read_bytes())
    def test_scan_is_explicitly_blocked(self):
        binary=ROOT/'.host-build/miniboxd-host'
        run=subprocess.run([str(binary),'--scan-status'],capture_output=True,text=True)
        self.assertEqual(run.returncode,0); self.assertIn('hp_proprietary_plugin_required',run.stdout)
if __name__=='__main__': unittest.main()
