import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from firmware_fixture import make_full_flash, make_mtd5


class ReleaseGateTests(unittest.TestCase):
    def test_extract_critical_regions_from_full_flash(self):
        with tempfile.TemporaryDirectory() as td:
            td = pathlib.Path(td)
            stock = td / "flash.bin"
            out = td / "critical"
            stock.write_bytes(make_full_flash())
            proc = subprocess.run(
                [sys.executable, str(ROOT / "tools/extract-critical-regions.py"), str(stock), str(out)],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            self.assertEqual((out / "u-boot.bin").stat().st_size, 0x20000)
            self.assertEqual((out / "art.bin").stat().st_size, 0x10000)

    def test_extract_refuses_mtd5_because_regions_are_not_inside_it(self):
        with tempfile.TemporaryDirectory() as td:
            td = pathlib.Path(td)
            stock = td / "firmware.bin"
            stock.write_bytes(make_mtd5())
            proc = subprocess.run(
                [sys.executable, str(ROOT / "tools/extract-critical-regions.py"), str(stock), str(td / "out")],
                capture_output=True,
                text=True,
            )
            self.assertNotEqual(proc.returncode, 0)
            self.assertIn("does not contain U-Boot or ART", proc.stdout + proc.stderr)

    def test_gate_accepts_mtd5_evidence_but_blocks_without_uboot_art_and_images(self):
        with tempfile.TemporaryDirectory() as td:
            td = pathlib.Path(td)
            stock = td / "firmware.bin"
            report = td / "gate.json"
            stock.write_bytes(make_mtd5())
            proc = subprocess.run(
                [sys.executable, str(ROOT / "tools/generate-release-gate.py"), "--root", str(ROOT), "--stock", str(stock), "--out", str(report)],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 10, proc.stdout + proc.stderr)
            gate = json.loads(report.read_text())
            self.assertEqual(gate["level"], "STOCK_MTD5_VERIFIED")
            self.assertFalse(gate["flash_allowed"])
            self.assertIn("uboot_dump_missing", gate["blockers"])
            self.assertIn("art_dump_missing", gate["blockers"])
            self.assertNotIn("stock_dump_invalid", gate["blockers"])
            self.assertIn("initramfs_image_missing", gate["blockers"])

    def test_gate_marks_full_flash_verified_but_still_blocks_without_images(self):
        with tempfile.TemporaryDirectory() as td:
            td = pathlib.Path(td)
            stock = td / "full-flash.bin"
            report = td / "gate.json"
            stock.write_bytes(make_full_flash())
            proc = subprocess.run(
                [sys.executable, str(ROOT / "tools/generate-release-gate.py"), "--root", str(ROOT), "--stock", str(stock), "--out", str(report)],
                capture_output=True, text=True,
            )
            self.assertEqual(proc.returncode, 10, proc.stdout + proc.stderr)
            gate = json.loads(report.read_text())
            self.assertEqual(gate["level"], "FULL_STOCK_FLASH_VERIFIED")
            self.assertNotIn("uboot_dump_missing", gate["blockers"])
            self.assertNotIn("art_dump_missing", gate["blockers"])
            self.assertIn("initramfs_image_missing", gate["blockers"])
            self.assertFalse(gate["flash_allowed"])

    def test_separate_critical_regions_validate(self):
        with tempfile.TemporaryDirectory() as td:
            td = pathlib.Path(td)
            full = make_full_flash()
            uboot = td / "uboot.bin"
            art = td / "art.bin"
            uboot.write_bytes(full[:0x20000])
            art.write_bytes(full[0xFF0000:])
            proc = subprocess.run(
                [sys.executable, str(ROOT / "tools/verify_critical_regions.py"), "--uboot", str(uboot), "--art", str(art), "--json"],
                capture_output=True,
                text=True,
            )
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            self.assertTrue(json.loads(proc.stdout)["pass"])


if __name__ == "__main__":
    unittest.main()
