import pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class SourcePolicyTests(unittest.TestCase):
    def test_no_usblp_path_or_package(self):
        texts=[]
        roots=[ROOT/'package', ROOT/'openwrt.config', ROOT/'board-port']
        for base in roots:
            paths=[base] if base.is_file() else list(base.rglob('*'))
            for p in paths:
                if p.is_file() and p.stat().st_size<500000:
                    texts.append(p.read_text(errors='ignore'))
        alltext='\n'.join(texts)
        self.assertNotIn('/dev/usb/lp',alltext)
        self.assertNotIn('CONFIG_PACKAGE_kmod-usb-printer=y',alltext)
    def test_addresses_are_separated(self):
        c=(ROOT/'package/minibox-mfp/files/www/index.html').read_text()
        info=(ROOT/'README.md').read_text()
        self.assertIn('192.168.55.250',info); self.assertIn('192.168.55.251',info); self.assertTrue(c)
    def test_image_recipe(self):
        m=(ROOT/'board-port/device.mk').read_text()
        self.assertIn('$(Device/tplink-16mlzma)',m); self.assertIn('0x3c000201',m); self.assertIn('SOC := ar9330',m); self.assertIn('kmod-usb-chipidea2',m)
    def test_initramfs_and_recovery_addresses(self):
        c=(ROOT/'openwrt.config').read_text(); d=(ROOT/'package/minibox-mfp/files/uci-defaults/90-minibox-network').read_text()
        self.assertIn('CONFIG_TARGET_ROOTFS_INITRAMFS=y',c)
        self.assertIn("192.168.55.251",d); self.assertIn("192.168.55.250",d)
        self.assertIn("disabled='1'",d)
    def test_modern_ath79_network_path(self):
        i=(ROOT/'scripts/inject-openwrt-tree.py').read_text()
        self.assertIn('target/linux/ath79/generic/base-files/etc/board.d/02_network',i)
        frag=(ROOT/'board-port/02_network.fragment').read_text()
        self.assertIn('ucidef_set_interfaces_lan_wan "eth1" "eth0"',frag)
        self.assertNotIn('target/linux/ath79/base-files/etc/board.d/02_network',i)
    def test_usb_transport_selects_printer_class(self):
        u=(ROOT/'package/minibox-mfp/src/usb_libusb.c').read_text()
        selector=(ROOT/'package/minibox-mfp/src/usb_select.c').read_text()
        self.assertIn('minibox_select_printer_endpoint',u)
        self.assertIn('USB_CLASS_PRINTER',selector)
        self.assertIn('kernel_driver_active_usblp_forbidden',u)
    def test_ubus_job_path_is_restricted(self):
        u=(ROOT/'package/minibox-mfp/src/ubus_api.c').read_text()
        self.assertIn('minibox_validate_job_path',u)
    def test_sighup_reload_is_event_loop_safe(self):
        u=(ROOT/'package/minibox-mfp/src/ubus_api.c').read_text()
        self.assertIn('volatile sig_atomic_t reload_requested',u)
        self.assertIn('maintenance_cb',u)
        self.assertIn('minibox_load_config()',u)
if __name__=='__main__': unittest.main()
