import pathlib, subprocess, sys, tempfile, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
class InjectionTests(unittest.TestCase):
    def test_injection_into_clean_shape(self):
        with tempfile.TemporaryDirectory() as td:
            t=pathlib.Path(td)
            (t/'target/linux/ath79/dts').mkdir(parents=True)
            (t/'target/linux/ath79/dts/ar9330.dtsi').write_text('/ { compatible = \"qca,ar9330\"; };\n')
            (t/'target/linux/ath79/image').mkdir(parents=True)
            (t/'target/linux/ath79/generic/base-files/etc/board.d').mkdir(parents=True)
            (t/'target/linux/ath79/image/common-tp-link.mk').write_text('define Device/tplink-16mlzma\nendef\n')
            (t/'target/linux/ath79/image/generic-tp-link.mk').write_text('include ./common-tp-link.mk\n')
            (t/'target/linux/ath79/generic/base-files/etc/board.d/02_network').write_text('ath79_setup_interfaces() {\n\tlocal board="$1"\n\tcase "$board" in\n\t*) ;;\n\tesac\n}\n')
            x=subprocess.run([sys.executable,str(ROOT/'scripts/inject-openwrt-tree.py'),str(t)],capture_output=True,text=True)
            self.assertEqual(x.returncode,0,x.stdout+x.stderr)
            self.assertTrue((t/'target/linux/ath79/dts/ar9330_gainstrong_minibox-v1.dts').is_file())
            self.assertIn('Device/gainstrong_minibox-v1',(t/'target/linux/ath79/image/generic-tp-link.mk').read_text())
            self.assertIn('gainstrong,minibox-v1)',(t/'target/linux/ath79/generic/base-files/etc/board.d/02_network').read_text())
            self.assertTrue((t/'package/minibox-mfp/src/main.c').is_file())
if __name__=='__main__': unittest.main()
