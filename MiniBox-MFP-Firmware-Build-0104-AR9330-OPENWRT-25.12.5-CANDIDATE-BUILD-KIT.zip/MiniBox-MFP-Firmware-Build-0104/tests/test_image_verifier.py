import hashlib
import json
import lzma
import pathlib
import struct
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
FW_LIMIT = 0xFD0000
HWID = 0x3C000201


def make_image(path: pathlib.Path, sysupgrade: bool) -> None:
    kernel = bytearray(b"K" * (1024 * 1024 + 4096))
    kernel[12345:12345 + len(b"gainstrong,minibox-v1")] = b"gainstrong,minibox-v1"
    packed = lzma.compress(bytes(kernel), format=lzma.FORMAT_ALONE)
    data = bytearray(b"\xff" * (0x200 + len(packed) + (0x4000 if sysupgrade else 0)))
    struct.pack_into(">I", data, 0x40, HWID)
    struct.pack_into(">I", data, 0x44, 1)
    struct.pack_into(">I", data, 0x7C, FW_LIMIT)
    struct.pack_into(">I", data, 0x80, 0x200)
    struct.pack_into(">I", data, 0x84, len(packed))
    struct.pack_into(">I", data, 0x88, 0)
    struct.pack_into(">I", data, 0x8C, 0)
    data[0x200:0x200 + len(packed)] = packed
    if sysupgrade:
        data[-4096:-4096 + len(b"gainstrong,minibox-v1")] = b"gainstrong,minibox-v1"
    path.write_bytes(data)


class ImageVerifierTests(unittest.TestCase):
    def test_valid_pair_passes(self):
        with tempfile.TemporaryDirectory() as td:
            d = pathlib.Path(td)
            make_image(d / "openwrt-ath79-generic-gainstrong_minibox-v1-initramfs-kernel.bin", False)
            make_image(d / "openwrt-ath79-generic-gainstrong_minibox-v1-squashfs-sysupgrade.bin", True)
            out = d / "report.json"
            x = subprocess.run([sys.executable, str(ROOT / "tools/verify-built-images.py"), "--dist", str(d), "--out", str(out)], capture_output=True, text=True)
            self.assertEqual(x.returncode, 0, x.stdout + x.stderr)
            self.assertTrue(json.loads(out.read_text())["pass"])

    def test_wrong_hwid_fails(self):
        with tempfile.TemporaryDirectory() as td:
            d = pathlib.Path(td)
            a=d / "openwrt-ath79-generic-gainstrong_minibox-v1-initramfs-kernel.bin"
            b=d / "openwrt-ath79-generic-gainstrong_minibox-v1-squashfs-sysupgrade.bin"
            make_image(a, False); make_image(b, True)
            raw=bytearray(b.read_bytes()); struct.pack_into(">I", raw, 0x40, 0xDEADBEEF); b.write_bytes(raw)
            out=d/'report.json'
            x=subprocess.run([sys.executable,str(ROOT/'tools/verify-built-images.py'),'--dist',str(d),'--out',str(out)],capture_output=True,text=True)
            self.assertNotEqual(x.returncode,0)
            self.assertIn('sysupgrade_verification_failed',json.loads(out.read_text())['blockers'])

if __name__ == '__main__':
    unittest.main()
