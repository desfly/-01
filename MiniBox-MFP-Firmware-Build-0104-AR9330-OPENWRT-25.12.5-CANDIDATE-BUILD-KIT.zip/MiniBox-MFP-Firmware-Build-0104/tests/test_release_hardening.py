import pathlib, unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]

class ReleaseHardeningTests(unittest.TestCase):
    def test_bootstrap_pins_exact_openwrt_tag_and_skips_feeds_by_default(self):
        s=(ROOT/'scripts/bootstrap-openwrt.sh').read_text()
        self.assertIn('OPENWRT_TAG:-v25.12.5', s)
        self.assertIn('describe --tags --exact-match', s)
        self.assertIn('${UPDATE_FEEDS:-0}', s)
        self.assertIn('feeds=SKIPPED', s)

    def test_safe_network_metrics(self):
        s=(ROOT/'package/minibox-mfp/files/uci-defaults/90-minibox-network').read_text()
        self.assertIn("set network.lan.defaultroute='0'", s)
        self.assertIn("set network.lan.metric='100'", s)
        self.assertIn("set network.wwan.metric='10'", s)

    def test_cgi_requires_exact_content_length(self):
        s=(ROOT/'package/minibox-mfp/files/cgi-bin/minibox-print').read_text()
        self.assertIn('head -c "$LEN"', s)
        self.assertIn('ACTUAL="$(wc -c', s)
        self.assertNotIn('iflag=count_bytes', s)

    def test_archive_is_prominently_non_flashable(self):
        s=(ROOT/'BUILD-NOT-FLASHABLE.txt').read_text()
        self.assertIn('NOT FLASHABLE', s)
        self.assertIn('flash_allowed', s)

if __name__=='__main__': unittest.main()
