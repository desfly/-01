import pathlib
import subprocess
import tempfile
import textwrap
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class JobValidationTests(unittest.TestCase):
    def build_harness(self, td):
        td = pathlib.Path(td)
        source = td / "h.c"
        binary = td / "h"
        source.write_text(textwrap.dedent(r'''
            #include "minibox.h"
            #include <stdint.h>
            #include <stdio.h>
            int main(int argc, char **argv) {
                uint64_t size = 0;
                int rc;
                if (argc != 2) return 2;
                rc = minibox_validate_job_path(argv[1], &size);
                printf("%d %llu\n", rc, (unsigned long long)size);
                return rc == 0 ? 0 : 1;
            }
        '''))
        build = subprocess.run([
            "cc", "-D_POSIX_C_SOURCE=200809L", "-std=c11", "-Wall",
            "-Wextra", "-Werror", "-I", str(ROOT / "package/minibox-mfp/src"),
            str(source), str(ROOT / "package/minibox-mfp/src/job_validate.c"),
            "-o", str(binary),
        ], capture_output=True, text=True)
        self.assertEqual(build.returncode, 0, build.stdout + build.stderr)
        return binary

    def test_valid_job_and_symlink_block(self):
        with tempfile.TemporaryDirectory() as td:
            binary = self.build_harness(td)
            spool = pathlib.Path("/tmp/minibox")
            spool.mkdir(mode=0o700, exist_ok=True)
            good = spool / "validator-test.pcl"
            outside = pathlib.Path(td) / "outside"
            link = spool / "validator-link.pcl"
            try:
                good.write_bytes(b"PCL")
                outside.write_bytes(b"outside")
                valid = subprocess.run([str(binary), str(good)], capture_output=True, text=True)
                self.assertEqual(valid.returncode, 0, valid.stdout + valid.stderr)
                link.unlink(missing_ok=True)
                link.symlink_to(outside)
                invalid = subprocess.run([str(binary), str(link)], capture_output=True, text=True)
                self.assertNotEqual(invalid.returncode, 0)
            finally:
                good.unlink(missing_ok=True)
                link.unlink(missing_ok=True)

    def test_outside_path_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            binary = self.build_harness(td)
            path = pathlib.Path(td) / "job"
            path.write_bytes(b"x")
            self.assertNotEqual(subprocess.run([str(binary), str(path)]).returncode, 0)


if __name__ == "__main__":
    unittest.main()
