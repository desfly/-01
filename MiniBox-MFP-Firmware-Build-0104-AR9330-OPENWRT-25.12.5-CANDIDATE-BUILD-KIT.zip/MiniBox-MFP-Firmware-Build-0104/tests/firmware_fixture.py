import lzma
import struct

FULL = 0x1000000
FW_OFF = 0x20000
FW_SIZE = 0xFD0000
ART_OFF = 0xFF0000


def minimal_squashfs() -> bytes:
    inode_table_start = 96
    root_inode = struct.pack("<4H2I", 1, 0o755, 0, 0, 0, 1)
    root_inode += struct.pack("<IIHHI", 0, 1, 3, 0, 1)
    inode_metadata = struct.pack("<H", 0x8000 | len(root_inode)) + root_inode
    bytes_used = inode_table_start + len(inode_metadata)
    superblock = struct.pack(
        "<5I6H8Q",
        0x73717368,
        1,
        0,
        262144,
        0,
        4,
        18,
        0,
        1,
        4,
        0,
        0,
        bytes_used,
        bytes_used,
        0xFFFFFFFFFFFFFFFF,
        inode_table_start,
        bytes_used,
        bytes_used,
        bytes_used,
    )
    return superblock + inode_metadata


def make_mtd5() -> bytes:
    kernel = lzma.compress(b"synthetic MiniBox test kernel", format=lzma.FORMAT_ALONE)
    rootfs = minimal_squashfs()
    data = bytearray(b"\xff" * FW_SIZE)
    data[:0x200] = b"\0" * 0x200
    data[0:4] = struct.pack("<I", 1)
    data[0x04:0x04 + len(b"OpenWrt")] = b"OpenWrt"
    data[0x1C:0x1C + len(b"TEST")] = b"TEST"
    struct.pack_into(">I", data, 0x40, 0x3C000201)
    struct.pack_into(">I", data, 0x44, 1)
    struct.pack_into(">I", data, 0x48, 0)
    struct.pack_into(">I", data, 0x74, 0x80060000)
    struct.pack_into(">I", data, 0x78, 0x80060000)
    struct.pack_into(">I", data, 0x7C, 0x00F80000)
    struct.pack_into(">I", data, 0x80, 0x200)
    struct.pack_into(">I", data, 0x84, len(kernel))
    struct.pack_into(">I", data, 0x88, 0x100000)
    struct.pack_into(">I", data, 0x8C, len(rootfs))
    root_off = 0x200 + len(kernel)
    data[0x200:root_off] = kernel
    data[root_off:root_off + len(rootfs)] = rootfs
    overlay = (root_off + len(rootfs) + 0xFFFF) & ~0xFFFF
    data[overlay:overlay + 4] = b"\x85\x19\x00\x00"
    return bytes(data)


def make_full_flash() -> bytes:
    data = bytearray(b"\xff" * FULL)
    # U-Boot area: nonempty, with a valid unicast MAC at 0x1fc00.
    data[0:16] = b"MINIBOX-UBOOT\0\0\0"
    data[0x1FC00:0x1FC06] = bytes.fromhex("02 11 22 33 44 55")
    data[FW_OFF:ART_OFF] = make_mtd5()
    art = bytes((i * 13 + 7) & 0xFF for i in range(0x10000))
    data[ART_OFF:] = art
    return bytes(data)
