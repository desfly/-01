import pathlib
import subprocess
import tempfile
import textwrap
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]


class UsbSelectorTests(unittest.TestCase):
    def test_vendor_bulk_is_ignored_and_printer_bulk_out_is_selected(self):
        with tempfile.TemporaryDirectory() as td:
            td = pathlib.Path(td)
            source = td / "selector.c"
            binary = td / "selector"
            source.write_text(textwrap.dedent(r'''
                #include "minibox.h"
                #include <stdio.h>
                int main(void) {
                    const minibox_usb_candidate_t items[] = {
                        {255, 0, 0, 0x01, 2},
                        {7,   2, 1, 0x82, 2},
                        {7,   2, 1, 0x03, 2}
                    };
                    uint8_t iface=0, alt=0, ep=0;
                    int rc=minibox_select_printer_endpoint(items,3,&iface,&alt,&ep);
                    printf("%d %u %u %u\n",rc,iface,alt,ep);
                    return (rc==0 && iface==2 && alt==1 && ep==3) ? 0 : 1;
                }
            '''))
            build = subprocess.run([
                "cc", "-std=c11", "-Wall", "-Wextra", "-Werror",
                "-I", str(ROOT / "package/minibox-mfp/src"),
                str(source), str(ROOT / "package/minibox-mfp/src/usb_select.c"),
                "-o", str(binary),
            ], capture_output=True, text=True)
            self.assertEqual(build.returncode, 0, build.stdout + build.stderr)
            run = subprocess.run([str(binary)], capture_output=True, text=True)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)

    def test_no_printer_interface_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            td = pathlib.Path(td)
            source = td / "selector.c"
            binary = td / "selector"
            source.write_text('#include "minibox.h"\nint main(void){minibox_usb_candidate_t x={255,1,0,1,2};uint8_t a,b,c;return minibox_select_printer_endpoint(&x,1,&a,&b,&c)==-2?0:1;}\n')
            build = subprocess.run(["cc","-std=c11","-Wall","-Wextra","-Werror","-I",str(ROOT/"package/minibox-mfp/src"),str(source),str(ROOT/"package/minibox-mfp/src/usb_select.c"),"-o",str(binary)],capture_output=True,text=True)
            self.assertEqual(build.returncode,0,build.stdout+build.stderr)
            self.assertEqual(subprocess.run([str(binary)]).returncode,0)


if __name__ == "__main__":
    unittest.main()
