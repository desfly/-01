#include "minibox.h"

#define USB_CLASS_PRINTER 7u
#define USB_TRANSFER_TYPE_MASK 0x03u
#define USB_TRANSFER_TYPE_BULK 0x02u
#define USB_ENDPOINT_DIR_MASK 0x80u

int minibox_select_printer_endpoint(const minibox_usb_candidate_t *items,
                                    size_t count,
                                    uint8_t *interface_number,
                                    uint8_t *alternate_setting,
                                    uint8_t *endpoint_address) {
    size_t i;
    if (!items || !interface_number || !alternate_setting || !endpoint_address)
        return -1;
    for (i = 0; i < count; ++i) {
        if (items[i].interface_class != USB_CLASS_PRINTER)
            continue;
        if ((items[i].endpoint_attributes & USB_TRANSFER_TYPE_MASK) != USB_TRANSFER_TYPE_BULK)
            continue;
        if ((items[i].endpoint_address & USB_ENDPOINT_DIR_MASK) != 0)
            continue;
        *interface_number = items[i].interface_number;
        *alternate_setting = items[i].alternate_setting;
        *endpoint_address = items[i].endpoint_address;
        return 0;
    }
    return -2;
}
