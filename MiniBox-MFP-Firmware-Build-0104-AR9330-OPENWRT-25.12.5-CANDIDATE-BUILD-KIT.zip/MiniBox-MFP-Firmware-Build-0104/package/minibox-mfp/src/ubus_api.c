#include "minibox.h"
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

#ifdef MINIBOX_WITH_UBUS
#include <libubox/blobmsg_json.h>
#include <libubox/uloop.h>
#include <libubus.h>

static struct blob_buf b;
static minibox_state_t *g_state;
static volatile sig_atomic_t reload_requested;
static struct uloop_timeout maintenance_timer;

static void sighup_handler(int signo) {
    (void)signo;
    reload_requested = 1;
}

static void maintenance_cb(struct uloop_timeout *timeout) {
    (void)timeout;
    if (reload_requested) {
        reload_requested = 0;
        (void)minibox_load_config();
    }
    uloop_timeout_set(&maintenance_timer, 500);
}

enum { PRINT_PATH, __PRINT_MAX };
static const struct blobmsg_policy print_policy[__PRINT_MAX] = {
    [PRINT_PATH] = { .name = "path", .type = BLOBMSG_TYPE_STRING },
};

static int status_cb(struct ubus_context *ctx, struct ubus_object *obj,
                     struct ubus_request_data *req, const char *method,
                     struct blob_attr *msg) {
    (void)obj; (void)method; (void)msg;
    blob_buf_init(&b, 0);
    blobmsg_add_string(&b, "service", "running");
    blobmsg_add_string(&b, "transport", "libusb");
    blobmsg_add_u8(&b, "printer_online", g_state->printer_online);
    blobmsg_add_u64(&b, "jobs_ok", g_state->jobs_ok);
    blobmsg_add_u64(&b, "jobs_failed", g_state->jobs_failed);
    blobmsg_add_string(&b, "scan", "plugin_required");
    ubus_send_reply(ctx, req, b.head);
    return 0;
}

static int print_cb(struct ubus_context *ctx, struct ubus_object *obj,
                    struct ubus_request_data *req, const char *method,
                    struct blob_attr *msg) {
    struct blob_attr *tb[__PRINT_MAX];
    int rc;
    uint64_t job_size = 0;
    (void)obj; (void)method;
    blobmsg_parse(print_policy, __PRINT_MAX, tb, blob_data(msg), blob_len(msg));
    if (!tb[PRINT_PATH]) return UBUS_STATUS_INVALID_ARGUMENT;
    if (minibox_validate_job_path(blobmsg_get_string(tb[PRINT_PATH]), &job_size) != 0)
        return UBUS_STATUS_PERMISSION_DENIED;
    g_state->cancel_requested = 0;
    rc = minibox_print_usb(blobmsg_get_string(tb[PRINT_PATH]), g_state);
    blob_buf_init(&b, 0);
    blobmsg_add_string(&b, "result", rc == 0 ? "accepted" : "failed");
    blobmsg_add_u32(&b, "crc32", g_state->last_crc32);
    blobmsg_add_u64(&b, "bytes", g_state->last_bytes);
    blobmsg_add_u64(&b, "job_size", job_size);
    if (rc != 0) blobmsg_add_string(&b, "error", g_state->last_error);
    ubus_send_reply(ctx, req, b.head);
    return rc == 0 ? 0 : UBUS_STATUS_UNKNOWN_ERROR;
}

static int cancel_cb(struct ubus_context *ctx, struct ubus_object *obj,
                     struct ubus_request_data *req, const char *method,
                     struct blob_attr *msg) {
    (void)obj; (void)method; (void)msg;
    g_state->cancel_requested = 1;
    blob_buf_init(&b, 0);
    blobmsg_add_string(&b, "cancel", "requested");
    ubus_send_reply(ctx, req, b.head);
    return 0;
}

static int scan_cb(struct ubus_context *ctx, struct ubus_object *obj,
                   struct ubus_request_data *req, const char *method,
                   struct blob_attr *msg) {
    (void)obj; (void)method; (void)msg;
    blob_buf_init(&b, 0);
    blobmsg_add_string(&b, "scan", "blocked");
    blobmsg_add_string(&b, "reason", "hp_proprietary_plugin_required");
    ubus_send_reply(ctx, req, b.head);
    return 0;
}

static const struct ubus_method methods[] = {
    UBUS_METHOD_NOARG("status", status_cb),
    UBUS_METHOD("print", print_cb, print_policy),
    UBUS_METHOD_NOARG("scan", scan_cb),
    UBUS_METHOD_NOARG("cancel", cancel_cb),
};
static struct ubus_object_type obj_type = UBUS_OBJECT_TYPE("minibox", methods);
static struct ubus_object obj = { .name = "minibox", .type = &obj_type, .methods = methods, .n_methods = ARRAY_SIZE(methods) };

int minibox_ubus_run(minibox_state_t *state) {
    struct ubus_context *ctx;
    const char *raw_env;
    unsigned raw_port = 9100;
    g_state = state;
    raw_env = getenv("MINIBOX_RAW_PORT");
    if (raw_env && *raw_env) {
        char *end = NULL;
        unsigned long value = strtoul(raw_env, &end, 10);
        if (end && *end == '\0' && value >= 1024 && value <= 65535)
            raw_port = (unsigned)value;
    }
    uloop_init();
    signal(SIGHUP, sighup_handler);
    maintenance_timer.cb = maintenance_cb;
    uloop_timeout_set(&maintenance_timer, 500);
    ctx = ubus_connect(NULL);
    if (!ctx) return 1;
    ubus_add_uloop(ctx);
    if (ubus_add_object(ctx, &obj) != 0) { ubus_free(ctx); uloop_done(); return 2; }
    if (minibox_raw9100_start(state, raw_port) != 0) { ubus_free(ctx); uloop_done(); return 3; }
    uloop_run();
    ubus_free(ctx);
    uloop_done();
    return 0;
}
#else
int minibox_ubus_run(minibox_state_t *state) {
    (void)state;
    fprintf(stderr, "ubus_backend_not_compiled\n");
    return 1;
}
#endif
