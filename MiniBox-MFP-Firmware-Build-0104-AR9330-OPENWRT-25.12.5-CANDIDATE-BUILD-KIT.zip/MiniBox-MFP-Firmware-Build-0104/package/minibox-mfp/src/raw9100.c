#include "minibox.h"
#include <stdio.h>

#ifdef MINIBOX_WITH_UBUS
#include <errno.h>
#include <fcntl.h>
#include <libubox/uloop.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

#define RAW_MAX_JOB (16u * 1024u * 1024u)

typedef struct raw_client {
    struct uloop_fd ufd;
    FILE *file;
    size_t bytes;
    char path[128];
    minibox_state_t *state;
} raw_client_t;

static struct uloop_fd listener;
static minibox_state_t *raw_state;

static void close_client(raw_client_t *client, int submit) {
    uloop_fd_delete(&client->ufd);
    close(client->ufd.fd);
    if (client->file) fclose(client->file);
    if (submit && client->bytes > 0 && !client->state->cancel_requested)
        (void)minibox_print_usb(client->path, client->state);
    unlink(client->path);
    client->state->cancel_requested = 0;
    free(client);
}

static void client_cb(struct uloop_fd *u, unsigned events) {
    raw_client_t *client = container_of(u, raw_client_t, ufd);
    unsigned char buf[8192];
    ssize_t n;
    (void)events;

    for (;;) {
        n = read(u->fd, buf, sizeof(buf));
        if (n > 0) {
            if (client->bytes + (size_t)n > RAW_MAX_JOB ||
                fwrite(buf, 1, (size_t)n, client->file) != (size_t)n) {
                close_client(client, 0);
                return;
            }
            client->bytes += (size_t)n;
            continue;
        }
        if (n == 0) {
            close_client(client, 1);
            return;
        }
        if (errno == EAGAIN || errno == EWOULDBLOCK) return;
        if (errno == EINTR) continue;
        close_client(client, 0);
        return;
    }
}

static void accept_cb(struct uloop_fd *u, unsigned events) {
    (void)events;
    for (;;) {
        raw_client_t *client;
        int fd, file_fd, flags;

        fd = accept(u->fd, NULL, NULL);
        if (fd < 0) {
            if (errno == EINTR) continue;
            return;
        }
        flags = fcntl(fd, F_GETFL, 0);
        if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
            close(fd);
            continue;
        }
        if (mkdir("/tmp/minibox", 0700) != 0 && errno != EEXIST) {
            close(fd);
            continue;
        }
        client = calloc(1, sizeof(*client));
        if (!client) {
            close(fd);
            continue;
        }
        client->ufd.fd = fd;
        client->ufd.cb = client_cb;
        client->state = raw_state;
        snprintf(client->path, sizeof(client->path), "/tmp/minibox/raw-XXXXXX");
        file_fd = mkstemp(client->path);
        if (file_fd < 0) {
            close(fd);
            free(client);
            continue;
        }
        client->file = fdopen(file_fd, "wb");
        if (!client->file) {
            close(file_fd);
            unlink(client->path);
            close(fd);
            free(client);
            continue;
        }
        if (uloop_fd_add(&client->ufd, ULOOP_READ | ULOOP_EDGE_TRIGGER) != 0) {
            close_client(client, 0);
            continue;
        }
    }
}

int minibox_raw9100_start(minibox_state_t *state, unsigned port) {
    struct sockaddr_in addr;
    int one = 1;

    listener.fd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
    if (listener.fd < 0) return -1;
    if (setsockopt(listener.fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) != 0) {
        close(listener.fd);
        return -1;
    }
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)port);
    if (bind(listener.fd, (struct sockaddr *)&addr, sizeof(addr)) != 0 ||
        listen(listener.fd, 4) != 0) {
        close(listener.fd);
        return -1;
    }
    raw_state = state;
    listener.cb = accept_cb;
    return uloop_fd_add(&listener, ULOOP_READ | ULOOP_EDGE_TRIGGER);
}
#else
int minibox_raw9100_start(minibox_state_t *state, unsigned port) {
    (void)state;
    (void)port;
    return 0;
}
#endif
