#include "minibox.h"
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>

#define JOB_ROOT "/tmp/minibox/"
#define JOB_MAX_BYTES (16u * 1024u * 1024u)

int minibox_validate_job_path(const char *path, uint64_t *size_out) {
    struct stat st;
    size_t root_len = strlen(JOB_ROOT);
    const char *name;

    if (!path || strncmp(path, JOB_ROOT, root_len) != 0)
        return -1;
    name = path + root_len;
    if (*name == '\0' || strcmp(name, ".") == 0 || strcmp(name, "..") == 0 ||
        strchr(name, '/') != NULL)
        return -1;
    if (lstat(path, &st) != 0 || !S_ISREG(st.st_mode) || st.st_size <= 0 ||
        (uint64_t)st.st_size > JOB_MAX_BYTES)
        return -2;
    if (size_out)
        *size_out = (uint64_t)st.st_size;
    return 0;
}
