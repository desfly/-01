#ifndef MINIBOX_H
#define MINIBOX_H

#include <stddef.h>
#include <stdint.h>

#define MINIBOX_USB_VID 0x03f0u
#define MINIBOX_USB_PID 0x4517u
#define MINIBOX_CHUNK_SIZE 16384u


typedef struct {
    uint8_t interface_class;
    uint8_t interface_number;
    uint8_t alternate_setting;
    uint8_t endpoint_address;
    uint8_t endpoint_attributes;
} minibox_usb_candidate_t;

int minibox_select_printer_endpoint(const minibox_usb_candidate_t *items,
                                    size_t count,
                                    uint8_t *interface_number,
                                    uint8_t *alternate_setting,
                                    uint8_t *endpoint_address);

typedef struct {
    int printer_online;
    uint64_t jobs_ok;
    uint64_t jobs_failed;
    uint32_t last_crc32;
    uint64_t last_bytes;
    char last_error[128];
    volatile int cancel_requested;
} minibox_state_t;

uint32_t minibox_crc32_file(const char *path, uint64_t *size_out);
int minibox_validate_job_path(const char *path, uint64_t *size_out);
int minibox_print_usb(const char *path, minibox_state_t *state);
int minibox_print_tcp(const char *endpoint, const char *path, minibox_state_t *state);
int minibox_load_config(void);
int minibox_ubus_run(minibox_state_t *state);
int minibox_raw9100_start(minibox_state_t *state, unsigned port);

#endif
