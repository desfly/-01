#include "minibox.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static void usage(const char *p) {
    fprintf(stderr, "usage: %s --daemon | --status | --scan-status | --print FILE [--tcp HOST:PORT] | --selftest\n", p);
}

int main(int argc, char **argv) {
    minibox_state_t state;
    const char *file = NULL;
    const char *tcp = NULL;
    int i;
    memset(&state, 0, sizeof(state));
    (void)minibox_load_config();

    if (argc == 2 && strcmp(argv[1], "--selftest") == 0) {
        if (MINIBOX_USB_VID != 0x03f0u || MINIBOX_USB_PID != 0x4517u) return 10;
        puts("selftest=PASS vid=03f0 pid=4517 transport=libusb-only scan=plugin_required");
        return 0;
    }
    if (argc == 2 && strcmp(argv[1], "--scan-status") == 0) {
        puts("{\"scan\":\"blocked\",\"reason\":\"hp_proprietary_plugin_required\"}");
        return 0;
    }
    if (argc == 2 && strcmp(argv[1], "--status") == 0) {
        puts("{\"service\":\"running\",\"transport\":\"libusb\",\"scan\":\"plugin_required\"}");
        return 0;
    }
    if (argc == 2 && strcmp(argv[1], "--daemon") == 0)
        return minibox_ubus_run(&state);

    for (i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--print") == 0 && i + 1 < argc) file = argv[++i];
        else if (strcmp(argv[i], "--tcp") == 0 && i + 1 < argc) tcp = argv[++i];
        else { usage(argv[0]); return 2; }
    }
    if (!file) { usage(argv[0]); return 2; }
    if (tcp) return minibox_print_tcp(tcp, file, &state) == 0 ? 0 : 1;
    return minibox_print_usb(file, &state) == 0 ? 0 : 1;
}
