#include "minibox.h"

#ifdef MINIBOX_WITH_UCI
#include <uci.h>
int minibox_load_config(void) {
    struct uci_context *ctx = uci_alloc_context();
    struct uci_package *pkg = NULL;
    int rc;
    if (!ctx) return -1;
    rc = uci_load(ctx, "minibox", &pkg);
    if (pkg) uci_unload(ctx, pkg);
    uci_free_context(ctx);
    return rc == UCI_OK ? 0 : -1;
}
#else
int minibox_load_config(void) { return 0; }
#endif
