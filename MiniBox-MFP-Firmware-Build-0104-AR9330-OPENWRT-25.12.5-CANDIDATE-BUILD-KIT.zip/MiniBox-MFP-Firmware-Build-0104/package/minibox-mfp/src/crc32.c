#include "minibox.h"
#include <stdio.h>

static uint32_t update(uint32_t crc, const unsigned char *data, size_t n) {
    size_t i;
    for (i = 0; i < n; ++i) {
        unsigned bit;
        crc ^= data[i];
        for (bit = 0; bit < 8; ++bit)
            crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
    }
    return crc;
}

uint32_t minibox_crc32_file(const char *path, uint64_t *size_out) {
    unsigned char buf[8192];
    uint32_t crc = 0xffffffffu;
    uint64_t size = 0;
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    for (;;) {
        size_t n = fread(buf, 1, sizeof(buf), f);
        if (n) {
            crc = update(crc, buf, n);
            size += (uint64_t)n;
        }
        if (n < sizeof(buf)) {
            if (ferror(f)) { fclose(f); return 0; }
            break;
        }
    }
    fclose(f);
    if (size_out) *size_out = size;
    return crc ^ 0xffffffffu;
}
