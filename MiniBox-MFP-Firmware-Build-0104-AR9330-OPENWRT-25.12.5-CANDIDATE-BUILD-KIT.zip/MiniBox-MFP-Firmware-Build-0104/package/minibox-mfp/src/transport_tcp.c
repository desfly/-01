#include "minibox.h"
#include <errno.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

static int send_all(int fd, const void *data, size_t len) {
    const unsigned char *p = data;
    while (len) {
        ssize_t n = send(fd, p, len, 0);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return -1;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return 0;
}

int minibox_print_tcp(const char *endpoint, const char *path, minibox_state_t *state) {
    char host[128], port[16], header[128], reply[128];
    const char *colon = strrchr(endpoint, ':');
    struct addrinfo hints, *res = NULL, *it;
    uint64_t size = 0, sent = 0;
    uint32_t crc;
    FILE *f = NULL;
    int fd = -1, rc = -1;
    unsigned char buf[MINIBOX_CHUNK_SIZE];
    if (!colon || colon == endpoint || strlen(colon + 1) >= sizeof(port)) return -1;
    if ((size_t)(colon - endpoint) >= sizeof(host)) return -1;
    memcpy(host, endpoint, (size_t)(colon - endpoint)); host[colon - endpoint] = 0;
    strcpy(port, colon + 1);
    crc = minibox_crc32_file(path, &size);
    if (!size) return -1;
    memset(&hints, 0, sizeof(hints)); hints.ai_socktype = SOCK_STREAM; hints.ai_family = AF_UNSPEC;
    if (getaddrinfo(host, port, &hints, &res) != 0) return -1;
    for (it = res; it; it = it->ai_next) {
        fd = socket(it->ai_family, it->ai_socktype, it->ai_protocol);
        if (fd >= 0 && connect(fd, it->ai_addr, it->ai_addrlen) == 0) break;
        if (fd >= 0) close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    if (fd < 0) return -1;
    snprintf(header, sizeof(header), "PRINT %llu %08x\n", (unsigned long long)size, crc);
    if (send_all(fd, header, strlen(header)) != 0) goto out;
    f = fopen(path, "rb"); if (!f) goto out;
    while (sent < size) {
        size_t n = fread(buf, 1, sizeof(buf), f);
        if (!n) goto out;
        if (send_all(fd, buf, n) != 0) goto out;
        sent += n;
    }
    shutdown(fd, SHUT_WR);
    {
        ssize_t n = recv(fd, reply, sizeof(reply)-1, 0);
        if (n <= 0) goto out;
        reply[n] = 0;
    }
    {
        char expected[32];
        snprintf(expected, sizeof(expected), "OK %08x", crc);
        if (strncmp(reply, expected, strlen(expected)) != 0) goto out;
    }
    state->jobs_ok++; state->last_crc32 = crc; state->last_bytes = size; rc = 0;
out:
    if (rc != 0) state->jobs_failed++;
    if (f) fclose(f);
    close(fd);
    return rc;
}
