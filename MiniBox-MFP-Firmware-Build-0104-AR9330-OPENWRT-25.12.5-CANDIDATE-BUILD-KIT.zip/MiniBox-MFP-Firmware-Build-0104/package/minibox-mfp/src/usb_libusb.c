#include "minibox.h"
#include <stdio.h>
#include <string.h>

#ifdef MINIBOX_WITH_LIBUSB
#include <libusb-1.0/libusb.h>

static void set_error(minibox_state_t *state, const char *msg) {
    if (!state) return;
    snprintf(state->last_error, sizeof(state->last_error), "%s", msg);
}

int minibox_print_usb(const char *path, minibox_state_t *state) {
    libusb_context *ctx = NULL;
    libusb_device_handle *handle = NULL;
    libusb_device **list = NULL;
    ssize_t count, i;
    int iface = -1, alt_setting = 0, claimed = 0;
    unsigned char endpoint = 0;
    FILE *file = NULL;
    unsigned char buf[MINIBOX_CHUNK_SIZE];
    int rc = -1;

    if (!state || !path) return -1;
    state->printer_online = 0;
    state->last_bytes = 0;
    state->last_crc32 = 0;
    state->last_error[0] = '\0';

    if (libusb_init(&ctx) != 0) {
        set_error(state, "libusb_init_failed");
        return -1;
    }
    count = libusb_get_device_list(ctx, &list);
    if (count < 0) {
        set_error(state, "usb_enumeration_failed");
        goto out;
    }

    for (i = 0; i < count && !handle; ++i) {
        struct libusb_device_descriptor dd;
        struct libusb_config_descriptor *cfg = NULL;
        int interface_index, alt_index, endpoint_index;

        if (libusb_get_device_descriptor(list[i], &dd) != 0) continue;
        if (dd.idVendor != MINIBOX_USB_VID || dd.idProduct != MINIBOX_USB_PID) continue;
        if (libusb_open(list[i], &handle) != 0) continue;
        if (libusb_get_active_config_descriptor(list[i], &cfg) != 0 &&
            libusb_get_config_descriptor(list[i], 0, &cfg) != 0) {
            libusb_close(handle);
            handle = NULL;
            continue;
        }

        {
            minibox_usb_candidate_t candidates[64];
            size_t candidate_count = 0;
            uint8_t selected_iface = 0, selected_alt = 0, selected_endpoint = 0;
            for (interface_index = 0; interface_index < cfg->bNumInterfaces; ++interface_index) {
                for (alt_index = 0;
                     alt_index < cfg->interface[interface_index].num_altsetting;
                     ++alt_index) {
                    const struct libusb_interface_descriptor *alt =
                        &cfg->interface[interface_index].altsetting[alt_index];
                    for (endpoint_index = 0;
                         endpoint_index < alt->bNumEndpoints && candidate_count < 64;
                         ++endpoint_index) {
                        const struct libusb_endpoint_descriptor *ep =
                            &alt->endpoint[endpoint_index];
                        candidates[candidate_count].interface_class = alt->bInterfaceClass;
                        candidates[candidate_count].interface_number = alt->bInterfaceNumber;
                        candidates[candidate_count].alternate_setting = alt->bAlternateSetting;
                        candidates[candidate_count].endpoint_address = ep->bEndpointAddress;
                        candidates[candidate_count].endpoint_attributes = ep->bmAttributes;
                        ++candidate_count;
                    }
                }
            }
            if (minibox_select_printer_endpoint(candidates, candidate_count,
                                                &selected_iface, &selected_alt,
                                                &selected_endpoint) == 0) {
                iface = selected_iface;
                alt_setting = selected_alt;
                endpoint = selected_endpoint;
            }
        }
        libusb_free_config_descriptor(cfg);
        if (!endpoint) {
            libusb_close(handle);
            handle = NULL;
        }
    }

    libusb_free_device_list(list, 1);
    list = NULL;
    if (!handle || iface < 0) {
        set_error(state, "hp_printer_interface_not_found");
        goto out;
    }
    if (libusb_kernel_driver_active(handle, iface) == 1) {
        set_error(state, "kernel_driver_active_usblp_forbidden");
        goto out;
    }
    if (libusb_claim_interface(handle, iface) != 0) {
        set_error(state, "usb_claim_failed");
        goto out;
    }
    claimed = 1;
    if (alt_setting != 0 &&
        libusb_set_interface_alt_setting(handle, iface, alt_setting) != 0) {
        set_error(state, "usb_altsetting_failed");
        goto release;
    }

    file = fopen(path, "rb");
    if (!file) {
        set_error(state, "job_open_failed");
        goto release;
    }
    for (;;) {
        size_t n = fread(buf, 1, sizeof(buf), file);
        size_t offset = 0;
        if (!n) break;
        while (offset < n) {
            int transferred = 0;
            int chunk = (int)(n - offset);
            int transfer_rc;
            if (state->cancel_requested) {
                set_error(state, "cancelled");
                goto release;
            }
            transfer_rc = libusb_bulk_transfer(handle, endpoint, buf + offset,
                                                chunk, &transferred, 30000);
            if (transfer_rc != 0 || transferred <= 0 || transferred > chunk) {
                set_error(state, "usb_bulk_transfer_failed");
                goto release;
            }
            offset += (size_t)transferred;
            state->last_bytes += (uint64_t)transferred;
        }
    }
    if (ferror(file)) {
        set_error(state, "job_read_failed");
        goto release;
    }

    state->printer_online = 1;
    state->jobs_ok++;
    state->last_crc32 = minibox_crc32_file(path, NULL);
    rc = 0;

release:
    if (file) fclose(file);
    if (claimed) libusb_release_interface(handle, iface);
out:
    if (list) libusb_free_device_list(list, 1);
    if (rc != 0) state->jobs_failed++;
    if (handle) libusb_close(handle);
    if (ctx) libusb_exit(ctx);
    return rc;
}
#else
int minibox_print_usb(const char *path, minibox_state_t *state) {
    (void)path;
    if (state) {
        state->jobs_failed++;
        snprintf(state->last_error, sizeof(state->last_error),
                 "libusb_backend_not_compiled");
    }
    return -1;
}
#endif
