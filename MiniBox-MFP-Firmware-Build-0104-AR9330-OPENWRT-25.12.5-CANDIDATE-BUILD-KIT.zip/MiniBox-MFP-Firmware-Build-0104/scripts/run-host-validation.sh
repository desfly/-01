#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/.host-build"
rm -rf "$BUILD"
mkdir -p "$BUILD"

cc -D_POSIX_C_SOURCE=200809L -std=c11 -Wall -Wextra -Werror -O2 \
  -I"$ROOT/package/minibox-mfp/src" \
  "$ROOT/package/minibox-mfp/src/main.c" \
  "$ROOT/package/minibox-mfp/src/crc32.c" \
  "$ROOT/package/minibox-mfp/src/transport_tcp.c" \
  "$ROOT/package/minibox-mfp/src/job_validate.c" \
  "$ROOT/package/minibox-mfp/src/usb_select.c" \
  "$ROOT/package/minibox-mfp/src/raw9100.c" \
  "$ROOT/package/minibox-mfp/src/usb_libusb.c" \
  "$ROOT/package/minibox-mfp/src/ubus_api.c" \
  "$ROOT/package/minibox-mfp/src/config_uci.c" \
  -o "$BUILD/miniboxd-host"

"$BUILD/miniboxd-host" --selftest
cc -D_POSIX_C_SOURCE=200809L -std=c11 -Wall -Wextra -Werror -fsyntax-only \
  -DMINIBOX_WITH_LIBUSB -DMINIBOX_WITH_UBUS -DMINIBOX_WITH_UCI \
  -I"$ROOT/package/minibox-mfp/src" -I"$ROOT/tests/mock_openwrt/include" \
  "$ROOT/package/minibox-mfp/src/main.c" \
  "$ROOT/package/minibox-mfp/src/crc32.c" \
  "$ROOT/package/minibox-mfp/src/transport_tcp.c" \
  "$ROOT/package/minibox-mfp/src/job_validate.c" \
  "$ROOT/package/minibox-mfp/src/usb_select.c" \
  "$ROOT/package/minibox-mfp/src/raw9100.c" \
  "$ROOT/package/minibox-mfp/src/usb_libusb.c" \
  "$ROOT/package/minibox-mfp/src/ubus_api.c" \
  "$ROOT/package/minibox-mfp/src/config_uci.c"
echo "openwrt_specific_c_syntax=PASS"
find "$ROOT" -type f -name "*.py" -print0 | xargs -0 python3 -m py_compile
for f in "$ROOT"/scripts/*.sh; do bash -n "$f"; done
for f in "$ROOT"/package/minibox-mfp/files/minibox.init "$ROOT"/package/minibox-mfp/files/cgi-bin/*; do sh -n "$f"; done
python3 -m unittest discover -s "$ROOT/tests" -v
python3 "$ROOT/tools/validate-source-tree.py" "$ROOT"
echo "host_validation=PASS"
