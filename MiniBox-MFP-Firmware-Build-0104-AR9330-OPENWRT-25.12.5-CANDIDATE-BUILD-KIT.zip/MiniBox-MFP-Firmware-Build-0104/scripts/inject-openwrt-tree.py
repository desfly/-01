#!/usr/bin/env python3
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = Path(sys.argv[1]).resolve()

required_upstream = [
    SRC / "target/linux/ath79/dts/ar9330.dtsi",
    SRC / "target/linux/ath79/image/common-tp-link.mk",
    SRC / "target/linux/ath79/image/generic-tp-link.mk",
    SRC / "target/linux/ath79/generic/base-files/etc/board.d/02_network",
]
missing = [str(p) for p in required_upstream if not p.is_file()]
if missing:
    raise SystemExit("not a compatible OpenWrt ath79 source tree; missing: " + ", ".join(missing))

# DTS
dts_src = ROOT / "board-port/target/linux/ath79/dts/ar9330_gainstrong_minibox-v1.dts"
dts_dst = SRC / "target/linux/ath79/dts/ar9330_gainstrong_minibox-v1.dts"
shutil.copy2(dts_src, dts_dst)

# Image profile (idempotent)
mk = SRC / "target/linux/ath79/image/generic-tp-link.mk"
text = mk.read_text()
fragment = (ROOT / "board-port/device.mk").read_text().strip()
if "Device/gainstrong_minibox-v1" not in text:
    mk.write_text(text.rstrip() + "\n\n" + fragment + "\n")

# Network profile (idempotent)
network = SRC / "target/linux/ath79/generic/base-files/etc/board.d/02_network"
nt = network.read_text()
if "gainstrong,minibox-v1)" not in nt:
    marker = 'case "$board" in'
    casepos = nt.find(marker)
    if casepos < 0:
        raise SystemExit("cannot locate ath79 board case")
    insert = nt.find("\n", casepos) + 1
    frag = "\tgainstrong,minibox-v1)\n\t\tucidef_set_interfaces_lan_wan \"eth1\" \"eth0\"\n\t\t;;\n"
    nt = nt[:insert] + frag + nt[insert:]
    network.write_text(nt)

# Package and deterministic config
pkg_dst = SRC / "package/minibox-mfp"
if pkg_dst.exists():
    shutil.rmtree(pkg_dst)
shutil.copytree(ROOT / "package/minibox-mfp", pkg_dst)
shutil.copy2(ROOT / "openwrt.config", SRC / ".config")

print("inject=PASS soc=ar9330 dts=ar9330_gainstrong_minibox-v1.dts lan=eth1 wan=eth0")
