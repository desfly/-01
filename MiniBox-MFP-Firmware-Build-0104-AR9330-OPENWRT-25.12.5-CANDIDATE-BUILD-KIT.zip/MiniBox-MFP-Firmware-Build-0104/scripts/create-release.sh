#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/scripts/run-host-validation.sh"
python3 "$ROOT/tools/make-manifest.py" "$ROOT"
echo "release_source_gate=PASS"
