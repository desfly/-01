#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="${OPENWRT_SRC:-$ROOT/openwrt-src}"
TAG="${OPENWRT_TAG:-v25.12.5}"
PRIMARY="${OPENWRT_PRIMARY_URL:-https://git.openwrt.org/openwrt/openwrt.git}"
MIRROR="${OPENWRT_MIRROR_URL:-https://github.com/openwrt/openwrt.git}"

for t in git make python3 sha256sum; do
  command -v "$t" >/dev/null || { echo "missing host tool: $t" >&2; exit 2; }
done

if [ ! -d "$SRC/.git" ]; then
  if ! git clone --filter=blob:none --depth 1 --branch "$TAG" "$PRIMARY" "$SRC"; then
    rm -rf "$SRC"
    git clone --filter=blob:none --depth 1 --branch "$TAG" "$MIRROR" "$SRC"
  fi
fi

# Fetch the exact signed/released tag from either source; never build moving HEAD.
if ! git -C "$SRC" fetch --force --depth 1 "$PRIMARY" "refs/tags/$TAG:refs/tags/$TAG"; then
  git -C "$SRC" fetch --force --depth 1 "$MIRROR" "refs/tags/$TAG:refs/tags/$TAG"
fi
git -C "$SRC" checkout --detach "$TAG"
actual_tag="$(git -C "$SRC" describe --tags --exact-match 2>/dev/null || true)"
[ "$actual_tag" = "$TAG" ] || { echo "unexpected OpenWrt revision: $actual_tag" >&2; exit 3; }

if [ "${UPDATE_FEEDS:-0}" = "1" ]; then
  "$SRC/scripts/feeds" update -a
  "$SRC/scripts/feeds" install -a
else
  echo "feeds=SKIPPED reason=core_only_build"
fi

python3 "$ROOT/scripts/inject-openwrt-tree.py" "$SRC"
echo "bootstrap=PASS source=$SRC tag=$TAG feeds=${UPDATE_FEEDS:-0}"
