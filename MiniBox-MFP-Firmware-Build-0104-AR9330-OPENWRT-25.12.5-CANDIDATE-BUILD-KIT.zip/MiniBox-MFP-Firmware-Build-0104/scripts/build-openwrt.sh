#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="${OPENWRT_SRC:-$ROOT/openwrt-src}"
JOBS="${JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)}"

[ -f "$SRC/Makefile" ] || { echo "run bootstrap-openwrt.sh first" >&2; exit 2; }
python3 "$ROOT/scripts/inject-openwrt-tree.py" "$SRC"
cp "$ROOT/openwrt.config" "$SRC/.config"
make -C "$SRC" defconfig

# Download first so checksum/network failures are separated from compilation errors.
make -C "$SRC" download -j"$JOBS" V=s
find "$SRC/dl" -type f -size -1024c -print -delete || true

if ! make -C "$SRC" -j"$JOBS" V=s; then
  echo "parallel build failed; retrying serially for deterministic diagnostics" >&2
  make -C "$SRC" -j1 V=sc
fi

TARGET="$SRC/bin/targets/ath79/generic"
python3 "$ROOT/tools/collect-images.py" "$TARGET" "$ROOT/dist"
python3 "$ROOT/tools/verify-built-images.py" --dist "$ROOT/dist" --out "$ROOT/reports/IMAGE-VERIFICATION.json"
python3 "$ROOT/tools/generate-release-gate.py" --root "$ROOT" --dist "$ROOT/dist" --image-verification "$ROOT/reports/IMAGE-VERIFICATION.json" --out "$ROOT/reports/release-gate.json" || test $? -eq 10

echo "build=PASS dist=$ROOT/dist"
