# MiniBox-MFP Firmware Build-0104

**Status: FULL_STOCK_FLASH_VERIFIED / CANDIDATE BUILD RECIPE READY — NOT FLASHABLE.**

Build-0104 verifies the device-specific U-Boot, stock firmware, ART calibration, and an exact 16 MiB stock recovery reconstruction. Candidate OpenWrt images are still absent and flash remains blocked until initramfs RAM-boot and physical libusb printing pass.

## Зафіксована мета

- OpenWrt 25.12.5 / ath79 / AR9330;
- 16 MiB SPI NOR, 64 MiB RAM;
- Wi-Fi client: `192.168.55.250`;
- Ethernet/LAN: `192.168.55.251`;
- друк через **libusb**, без `usblp`, без CUPS;
- один `miniboxd`, UCI + ubus + procd;
- Windows RAW printing на TCP/9100 та HTTP upload;
- мінімальний HTML Web UI, без LuCI;
- спочатку RAM-boot initramfs, тільки потім flash.

## Чесний статус

Цей архів містить повний код, board-port, OpenWrt package, CI-збірку,
емулятори USB/flash та release gate. Оригінальний mtd5 уже структурно перевірено. У поточному контейнері може бути недоступний OpenWrt MIPS toolchain/QEMU AR933x; готові образи вважаються дійсними лише після відтворюваної збірки та release gate.
Реальний образ будується скриптом `scripts/build-openwrt.sh` або GitHub Actions. Точні Ubuntu-команди наведено в `docs/BUILD-ON-UBUNTU.md`.

Сканування HP M1522n в HPLIP потребує закритого HP plug-in. Він не входить до
архіву і не може розповсюджуватися разом із прошивкою. До його окремого
легального встановлення API повертає `plugin_required`, а не фальшивий PASS.

## Швидка локальна перевірка

```sh
./scripts/run-host-validation.sh
```

## Збірка OpenWrt

```sh
./scripts/bootstrap-openwrt.sh
./scripts/build-openwrt.sh
```

Результати очікуються в `openwrt-src/bin/targets/ath79/generic/`.

## Безпечний порядок запуску

1. Перевірити mtd5 або повний flash dump через `tools/verify_stock_dump.py`.
2. Окремо перевірити mtd0 U-Boot і mtd4 ART через `tools/verify_critical_regions.py`.
3. Зібрати рівно два кандидати: initramfs і sysupgrade.
4. Завантажити initramfs у RAM через U-Boot/TFTP — без запису flash.
5. Перевірити UART, LAN, Wi-Fi, USB та ART/calibration.
6. Лише після PASS дозволяється sysupgrade.

Див. `docs/FLASHING-GATE.md`, `docs/RAM-BOOT.md` та `docs/KNOWN-LIMITATIONS.md`.

## Початкова мережа

- Ethernet/LAN одразу: `192.168.55.251/24`.
- Wi-Fi STA зарезервовано: `192.168.55.250/24`, але він вимкнений до введення власником SSID/ключа:

```sh
minibox-wifi-setup 'SSID' 'PASSWORD' '192.168.55.1' '192.168.55.1'
```

Жодні облікові дані Wi-Fi в образ не вбудовуються.

## Перевірений stock mtd5

mtd0, mtd5 і mtd4 уже перевірені; приватний recovery-пакет зберігається окремо від цього source ZIP.

## Реальна збірка кандидатів

Див. `docs/BUILD-WITH-GITHUB-ACTIONS.md`. Після зеленої CI-збірки завантажуються два `.bin`, але sysupgrade все одно заблокований до фізичного RAM-boot.
