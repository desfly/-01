#!/usr/bin/env python3
"""Reconstruct a device-specific 16 MiB stock flash from verified mtd0+mtd5+mtd4 backups.

This tool never writes to a device. It only reads local backup files and writes a local image.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

UBOOT_SIZE = 0x20000
FIRMWARE_SIZE = 0xFD0000
ART_SIZE = 0x10000
FULL_SIZE = 0x1000000


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--uboot", type=Path, required=True)
    ap.add_argument("--firmware", type=Path, required=True)
    ap.add_argument("--art", type=Path, required=True)
    ap.add_argument("--backup-report", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--report", type=Path, required=True)
    args = ap.parse_args()

    parts = {
        "uboot": (args.uboot, UBOOT_SIZE),
        "firmware": (args.firmware, FIRMWARE_SIZE),
        "art": (args.art, ART_SIZE),
    }
    data: dict[str, bytes] = {}
    blockers: list[str] = []
    details: dict[str, dict[str, object]] = {}
    for name, (path, expected_size) in parts.items():
        blob = path.read_bytes()
        data[name] = blob
        details[name] = {
            "file": path.name,
            "size": len(blob),
            "expected_size": expected_size,
            "sha256": sha256_bytes(blob),
        }
        if len(blob) != expected_size:
            blockers.append(f"{name}_size_mismatch")

    backup_match: dict[str, bool] = {}
    if args.backup_report:
        report = json.loads(args.backup_report.read_text(encoding="utf-8-sig"))
        backup_match = {
            "operation_read_only": report.get("operation") == "read-only backup",
            "writes_to_flash_false": report.get("writes_to_flash") is False,
            "pass_true": report.get("pass") is True,
            "uboot_size": report.get("uboot", {}).get("size") == len(data["uboot"]),
            "uboot_sha256": report.get("uboot", {}).get("sha256") == details["uboot"]["sha256"],
            "art_size": report.get("art", {}).get("size") == len(data["art"]),
            "art_sha256": report.get("art", {}).get("sha256") == details["art"]["sha256"],
        }
        if not all(backup_match.values()):
            blockers.append("backup_report_mismatch")

    image = data["uboot"] + data["firmware"] + data["art"]
    if len(image) != FULL_SIZE:
        blockers.append("full_flash_size_mismatch")
    if blockers:
        result = {
            "schema": 1,
            "pass": False,
            "blockers": blockers,
            "parts": details,
            "backup_report_match": backup_match,
        }
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        raise SystemExit(3)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_bytes(image)
    result = {
        "schema": 1,
        "pass": True,
        "blockers": [],
        "device_specific": True,
        "warning": "Contains device-specific U-Boot, MAC data, and ART calibration. Do not share or flash on another device.",
        "parts": details,
        "backup_report_match": backup_match,
        "full_flash": {
            "file": args.out.name,
            "size": args.out.stat().st_size,
            "sha256": sha256_file(args.out),
            "layout": [
                {"name": "u-boot", "offset": "0x000000", "size": "0x020000"},
                {"name": "firmware", "offset": "0x020000", "size": "0xfd0000"},
                {"name": "art", "offset": "0xff0000", "size": "0x010000"},
            ],
        },
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
