#!/usr/bin/env python3
import argparse, hashlib, pathlib

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('root',type=pathlib.Path); ap.add_argument('manifest',type=pathlib.Path); a=ap.parse_args()
    count=0
    for line in a.manifest.read_text().splitlines():
        if not line.strip(): continue
        digest,rel=line.split('  ',1); p=a.root/rel
        if not p.is_file() or sha(p)!=digest: raise SystemExit(f'manifest_mismatch: {rel}')
        count+=1
    print(f'manifest=PASS files={count}')
if __name__=='__main__': main()
