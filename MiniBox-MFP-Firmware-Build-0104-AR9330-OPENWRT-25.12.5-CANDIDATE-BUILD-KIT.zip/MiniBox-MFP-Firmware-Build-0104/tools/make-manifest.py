#!/usr/bin/env python3
from pathlib import Path
import hashlib
import sys

root = Path(sys.argv[1])
excluded_dirs = {'.host-build', '__pycache__', 'openwrt-src', 'dist', 'critical-backups'}
lines = []
for path in sorted(root.rglob('*')):
    if not path.is_file() or path.name == 'MANIFEST.sha256' or path.suffix == '.pyc':
        continue
    if any(part in excluded_dirs for part in path.parts):
        continue
    lines.append(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root).as_posix()}')
(root / 'MANIFEST.sha256').write_text('\n'.join(lines) + '\n')
print(f'manifest_files={len(lines)}')
