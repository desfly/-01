#!/usr/bin/env python3
from pathlib import Path
import sys
r=Path(sys.argv[1])
required=['README.md','BUILD_INFO.md','openwrt.config','board-port/target/linux/ath79/dts/ar9330_gainstrong_minibox-v1.dts','board-port/device.mk','package/minibox-mfp/Makefile','package/minibox-mfp/src/main.c','package/minibox-mfp/src/usb_libusb.c','emulator/usb_mfp_emulator.py','emulator/flash16_emulator.py','tools/verify_stock_dump.py','tools/stock_firmware.py','tools/analyze_stock_dump.py','tools/verify_critical_regions.py','tools/reconstruct-stock-fullflash.py','tools/extract-critical-regions.py','tools/generate-release-gate.py','tools/verify-built-images.py','docs/BUILD-WITH-GITHUB-ACTIONS.md','docs/RAM-BOOT.md','docs/STOCK-DUMP-STATUS.md','docs/READ-CRITICAL-MTD.md','package/minibox-mfp/src/raw9100.c','package/minibox-mfp/files/uci-defaults/90-minibox-network','.github/workflows/build-firmware.yml','docs/KNOWN-LIMITATIONS.md','docs/BUILD-ON-UBUNTU.md','tools/windows/Get-MiniBox-CriticalBackups.ps1','tools/windows/Get-MiniBox-CriticalBackups.cmd','BUILD-NOT-FLASHABLE.txt','LICENSE']
missing=[x for x in required if not (r/x).is_file()]
if missing: raise SystemExit('missing: '+', '.join(missing))
policy_roots=[r/'package', r/'openwrt.config', r/'board-port']
policy_files=[]
for base in policy_roots:
    policy_files.extend([base] if base.is_file() else [p for p in base.rglob('*') if p.is_file()])
alltext='\n'.join(p.read_text(errors='ignore') for p in policy_files if p.stat().st_size<1_000_000)
fulltext='\n'.join(p.read_text(errors='ignore') for p in r.rglob('*') if p.is_file() and p.stat().st_size<1_000_000)
checks={
 'correct_vid_pid':'0x03f0u' in alltext and '0x4517u' in alltext,
 'no_usblp_device':'/dev/usb/lp' not in alltext,
 'no_usblp_package':'kmod-usb-printer=y' not in alltext,
 'libusb':'MINIBOX_WITH_LIBUSB' in alltext,
 'ubus':'UBUS_METHOD("print"' in alltext,
 'uci':'uci_load(ctx, "minibox"' in alltext,
 'gpio_led':'gpio 1 GPIO_ACTIVE_LOW' in alltext,
 'gpio_reset':'gpio 11 GPIO_ACTIVE_HIGH' in alltext,
 'mac_offset':'macaddr@1fc00' in alltext,
 'art_offset':'partition@ff0000' in alltext,
 'calibration':'reg = <0x1000 0x440>' in alltext,
 'scan_gate':'hp_proprietary_plugin_required' in alltext,
 'ram_boot_gate':'RAM-boot' in fulltext or 'RAM_BOOT_PASS' in fulltext,
 'modern_network_path':'ath79/generic/base-files/etc/board.d/02_network' in fulltext and 'ucidef_set_interfaces_lan_wan "eth1" "eth0"' in fulltext,
 'initramfs_enabled':'CONFIG_TARGET_ROOTFS_INITRAMFS=y' in alltext,
 'raw9100':'minibox_raw9100_start' in alltext,
 'lan_static':'192.168.55.251' in alltext,
 'wifi_static':'192.168.55.250' in alltext,
 'mac_increments':'mac-address-increment = <1>' in alltext and 'mac-address-increment = <(-1)>' in alltext,
 'job_path_guard':'minibox_validate_job_path' in alltext,
 'printer_class_guard':'USB_CLASS_PRINTER' in alltext,
 'usb_selector':'minibox_select_printer_endpoint' in alltext,
 'sighup_reload':'volatile sig_atomic_t reload_requested' in alltext and 'maintenance_cb' in alltext,
 'deterministic_tag':'OPENWRT_TAG:-v25.12.5' in fulltext and 'describe --tags --exact-match' in fulltext,
 'feeds_opt_in':'UPDATE_FEEDS:-0' in fulltext and 'core_only_build' in fulltext,
 'lan_route_safety':"set network.lan.defaultroute='0'" in alltext and "set network.wwan.metric='10'" in alltext,
 'cgi_exact_body':'head -c "$LEN"' in alltext and 'ACTUAL=' in alltext,
 'not_flashable_marker':'NOT FLASHABLE' in fulltext,
 'ci_release_gate':'generate-release-gate.py' in fulltext and '--image-verification' in fulltext,
 'ar9330_profile':'#include "ar9330.dtsi"' in alltext and 'SOC := ar9330' in alltext and 'kmod-usb-chipidea2' in alltext,
 'image_verifier':'verify-built-images.py' in fulltext and 'candidate_image_verification_failed' in fulltext,
 'license_present':(r/'LICENSE').is_file() and (r/'LICENSE').stat().st_size>1000,
}
for k,v in checks.items(): print(f'{k}={"PASS" if v else "FAIL"}')
if not all(checks.values()): raise SystemExit(4)
print(f'source_tree=PASS required={len(required)} checks={len(checks)}')
