#!/usr/bin/env python3
"""Create a sanitized stock-firmware evidence report for Build-0104."""
import argparse
import json
import pathlib
import re

from stock_firmware import analyze_dump

SAFE_PATHS = (
    "/etc/openwrt_release",
    "/etc/openwrt_version",
    "/lib/ar71xx.sh",
    "/etc/board.d/02_network",
    "/lib/upgrade/platform.sh",
    "/etc/config/system",
)


def matching_lines(text: str, patterns: tuple[str, ...], context: int = 2) -> list[str]:
    lines = text.splitlines()
    hits = set()
    regexes = [re.compile(p, re.I) for p in patterns]
    for index, line in enumerate(lines):
        if any(rx.search(line) for rx in regexes):
            for pos in range(max(0, index - context), min(len(lines), index + context + 1)):
                hits.add(pos)
    return [f"{i + 1}: {lines[i]}" for i in sorted(hits)]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("dump", type=pathlib.Path)
    ap.add_argument("--type", choices=("auto", "full-flash", "mtd5"), default="auto")
    ap.add_argument("--json-out", type=pathlib.Path, required=True)
    ap.add_argument("--text-out", type=pathlib.Path, required=True)
    args = ap.parse_args()

    result = analyze_dump(args.dump, args.type, SAFE_PATHS)
    evidence = result.pop("extracted_files", {})

    snippets = {}
    for path, entry in evidence.items():
        if "text" not in entry or entry.get("text") is None:
            snippets[path] = entry
            continue
        text = entry["text"]
        if path == "/lib/ar71xx.sh":
            snippets[path] = {
                "size": entry["size"],
                "sha256": entry["sha256"],
                "matching_lines": matching_lines(text, (r"minibox", r"3c0002"), 4),
            }
        elif path == "/etc/board.d/02_network":
            snippets[path] = {
                "size": entry["size"],
                "sha256": entry["sha256"],
                "matching_lines": matching_lines(text, (r"minibox",), 30),
            }
        elif path == "/lib/upgrade/platform.sh":
            snippets[path] = {
                "size": entry["size"],
                "sha256": entry["sha256"],
                "matching_lines": matching_lines(text, (r"minibox", r"tplink"), 4),
            }
        else:
            snippets[path] = {
                "size": entry.get("size"),
                "sha256": entry.get("sha256"),
                "text": text,
            }

    result["sanitized_stock_evidence"] = snippets
    result["privacy"] = {
        "jffs2_overlay_extracted": False,
        "wifi_credentials_extracted": False,
        "only_immutable_squashfs_files_examined": True,
    }

    args.json_out.parent.mkdir(parents=True, exist_ok=True)
    args.text_out.parent.mkdir(parents=True, exist_ok=True)
    args.json_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    h = result.get("header", {})
    sec = result.get("sections", {})
    root = sec.get("rootfs", {})
    overlay = sec.get("overlay", {})
    lines = [
        "MiniBox-MFP Build-0104 — STOCK DUMP ANALYSIS",
        "================================================",
        f"file: {args.dump.name}",
        f"dump_type: {result.get('dump_type')}",
        f"size: {result.get('size')} ({result.get('size_hex')})",
        f"sha256: {result.get('sha256')}",
        f"pass: {str(result.get('pass')).lower()}",
        "",
        "TP-Link/OpenWrt header",
        f"  vendor: {h.get('vendor')}",
        f"  firmware version: {h.get('fw_version')}",
        f"  HWID: {h.get('hwid_hex')}",
        f"  hardware revision: {h.get('hw_revision')}",
        f"  kernel: {h.get('kernel_offset_hex')} + {h.get('kernel_length_hex')}",
        f"  actual SquashFS: {h.get('actual_rootfs_offset_hex')} + {h.get('rootfs_length_hex')}",
        "",
        "Immutable sections",
        f"  kernel stored SHA-256: {sec.get('kernel', {}).get('sha256')}",
        f"  kernel decompressed bytes: {sec.get('kernel', {}).get('decompressed_size')}",
        f"  rootfs SHA-256: {root.get('sha256')}",
        f"  SquashFS entries: {root.get('tree_entries')}",
        f"  SquashFS compression: {(root.get('squashfs') or {}).get('compression_name')}",
        "",
        "Writable overlay",
        f"  starts at: {overlay.get('offset_hex')}",
        f"  bytes: {overlay.get('stored_size')}",
        f"  JFFS2 signatures: {overlay.get('jffs2_magic_count')}",
        "  privacy: overlay contents were NOT extracted",
        "",
        "Checks",
    ]
    lines.extend(f"  {name}: {'PASS' if passed else 'FAIL'}" for name, passed in result.get("checks", {}).items())
    if result.get("warnings"):
        lines.append("")
        lines.append("Expected limitations")
        lines.extend(f"  {item}" for item in result["warnings"])
    if result.get("blockers"):
        lines.append("")
        lines.append("Blockers")
        lines.extend(f"  {item}" for item in result["blockers"])
    lines.extend([
        "",
        "Board evidence from immutable stock SquashFS",
        "  machine: MiniBox V1.0 -> minibox-v1",
        "  TP-Link HWID prefix: 3C0002",
        "  stock ar71xx network definition: eth0 LAN / eth2 WAN plus switch0 LAN ports",
        "",
        "Flash-safety conclusion",
        "  mtd5 firmware backup is structurally valid.",
        "  It does NOT contain mtd0 U-Boot or mtd4 ART/calibration/MAC.",
        "  Flash remains blocked until separate read-only mtd0 and mtd4 backups are verified.",
    ])
    args.text_out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"pass": result.get("pass"), "json": str(args.json_out), "text": str(args.text_out)}, indent=2))
    raise SystemExit(0 if result.get("pass") else 3)


if __name__ == "__main__":
    main()
