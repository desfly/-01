@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Get-MiniBox-CriticalBackups.ps1" %*
exit /b %errorlevel%
