param(
  [string]$HostAddress = "192.168.55.251"
)
$ErrorActionPreference = "Stop"
$opts = @("-o","HostKeyAlgorithms=+ssh-rsa","-o","PubkeyAcceptedAlgorithms=+ssh-rsa","-o","MACs=+hmac-sha1")
Write-Host "Checking RAM-boot candidate at $HostAddress"
& ssh.exe @opts "root@$HostAddress" @'
set -eu
echo "=== release ==="; cat /etc/openwrt_release
echo "=== model ==="; cat /tmp/sysinfo/model
echo "=== mtd ==="; cat /proc/mtd
echo "=== network ==="; ip -br link; ip -br addr
echo "=== usb ==="; lsusb
echo "=== forbidden usblp ==="; ! lsmod | grep -q usblp
echo "=== minibox ==="; /usr/sbin/miniboxd --selftest
'@
if ($LASTEXITCODE -ne 0) { throw "RAM-boot preflight failed" }
Write-Host "ram_boot_preflight=PASS"
