[CmdletBinding()]
param(
    [string]$Address,
    [string]$OutputDirectory = (Join-Path $PSScriptRoot "..\..\critical-backups")
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Require-Command([string]$Name) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required command not found: $Name"
    }
}

Require-Command "ssh.exe"
Require-Command "scp.exe"

$Candidates = if ($Address) { @($Address) } else { @("192.168.55.250", "192.168.55.251") }
$Selected = $null
foreach ($Candidate in $Candidates) {
    try {
        if (Test-NetConnection -ComputerName $Candidate -Port 22 -InformationLevel Quiet -WarningAction SilentlyContinue) {
            $Selected = $Candidate
            break
        }
    } catch { }
}
if (-not $Selected) {
    throw "MiniBox SSH was not found at 192.168.55.250 or 192.168.55.251"
}

$SshOptions = @(
    "-o", "HostKeyAlgorithms=+ssh-rsa",
    "-o", "PubkeyAcceptedAlgorithms=+ssh-rsa",
    "-o", "MACs=+hmac-sha1"
)
$Remote = "root@$Selected"
$RemoteUboot = "/tmp/minibox-mtd0-uboot.bin"
$RemoteArt = "/tmp/minibox-mtd4-art.bin"

New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$Stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$UbootLocal = Join-Path $OutputDirectory "MiniBox-mtd0-U-Boot-$Stamp.bin"
$ArtLocal = Join-Path $OutputDirectory "MiniBox-mtd4-ART-$Stamp.bin"
$ReportPath = Join-Path $OutputDirectory "MiniBox-critical-backup-$Stamp.json"

$ReadCommand = @'
set -e
rm -f /tmp/minibox-mtd0-uboot.bin /tmp/minibox-mtd4-art.bin
dd if=/dev/mtd0 of=/tmp/minibox-mtd0-uboot.bin bs=65536 2>/dev/null
dd if=/dev/mtd4 of=/tmp/minibox-mtd4-art.bin bs=65536 2>/dev/null
sync
[ "$(wc -c < /tmp/minibox-mtd0-uboot.bin)" -eq 131072 ]
[ "$(wc -c < /tmp/minibox-mtd4-art.bin)" -eq 65536 ]
sha256sum /tmp/minibox-mtd0-uboot.bin /tmp/minibox-mtd4-art.bin
'@

try {
    Write-Host "Reading mtd0 and mtd4 from MiniBox $Selected (read-only)..."
    & ssh.exe @SshOptions $Remote $ReadCommand
    if ($LASTEXITCODE -ne 0) { throw "Remote read failed with exit code $LASTEXITCODE" }

    & scp.exe @SshOptions "${Remote}:$RemoteUboot" $UbootLocal
    if ($LASTEXITCODE -ne 0) { throw "U-Boot SCP failed with exit code $LASTEXITCODE" }
    & scp.exe @SshOptions "${Remote}:$RemoteArt" $ArtLocal
    if ($LASTEXITCODE -ne 0) { throw "ART SCP failed with exit code $LASTEXITCODE" }

    $UbootSize = (Get-Item $UbootLocal).Length
    $ArtSize = (Get-Item $ArtLocal).Length
    if ($UbootSize -ne 131072) { throw "Invalid U-Boot size: $UbootSize; expected 131072" }
    if ($ArtSize -ne 65536) { throw "Invalid ART size: $ArtSize; expected 65536" }

    $UbootHash = (Get-FileHash -Algorithm SHA256 $UbootLocal).Hash.ToLowerInvariant()
    $ArtHash = (Get-FileHash -Algorithm SHA256 $ArtLocal).Hash.ToLowerInvariant()
    $Report = [ordered]@{
        schema = 1
        operation = "read-only backup"
        minibox_address = $Selected
        created_utc = (Get-Date).ToUniversalTime().ToString("o")
        writes_to_flash = $false
        uboot = [ordered]@{ file = (Split-Path $UbootLocal -Leaf); size = $UbootSize; sha256 = $UbootHash }
        art = [ordered]@{ file = (Split-Path $ArtLocal -Leaf); size = $ArtSize; sha256 = $ArtHash }
        pass = $true
    }
    $Report | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 $ReportPath

    Write-Host "PASS: critical backups created"
    Write-Host "U-Boot: $UbootLocal"
    Write-Host "ART:    $ArtLocal"
    Write-Host "Report: $ReportPath"
} finally {
    & ssh.exe @SshOptions $Remote "rm -f '$RemoteUboot' '$RemoteArt'" 2>$null | Out-Null
}
