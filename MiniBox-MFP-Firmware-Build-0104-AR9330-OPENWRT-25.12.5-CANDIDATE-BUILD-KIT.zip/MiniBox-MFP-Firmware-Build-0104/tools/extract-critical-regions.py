#!/usr/bin/env python3
"""Extract mtd0 and mtd4 only from a verified full 16 MiB flash dump."""
import argparse
import hashlib
import json
import pathlib

from stock_firmware import ART_OFFSET, ART_SIZE, DumpView, UBOOT_SIZE


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("dump", type=pathlib.Path)
    ap.add_argument("outdir", type=pathlib.Path)
    args = ap.parse_args()
    data = args.dump.read_bytes()
    try:
        view = DumpView.from_bytes(data, "full-flash")
    except ValueError as exc:
        raise SystemExit(
            f"{exc}; mtd5 firmware backup does not contain U-Boot or ART; "
            "read /dev/mtd0 and /dev/mtd4 separately"
        )
    assert view.uboot is not None and view.art is not None
    args.outdir.mkdir(parents=True, exist_ok=True)
    regions = {}
    for name, blob, offset in (
        ("u-boot", view.uboot, 0),
        ("art", view.art, ART_OFFSET),
    ):
        target = args.outdir / f"{name}.bin"
        target.write_bytes(blob)
        regions[name] = {"offset": offset, "size": len(blob), "sha256": sha(blob), "file": target.name}
    manifest = {"source": str(args.dump), "source_sha256": sha(data), "regions": regions}
    (args.outdir / "critical-regions.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
