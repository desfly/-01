#!/usr/bin/env python3
import hashlib
import json
import pathlib
import shutil
import sys

src = pathlib.Path(sys.argv[1])
dst = pathlib.Path(sys.argv[2])
dst.mkdir(parents=True, exist_ok=True)
for old in dst.glob("*"):
    if old.is_file():
        old.unlink()

patterns = {
    "initramfs": "*gainstrong_minibox-v1*initramfs*.bin",
    "sysupgrade": "*gainstrong_minibox-v1*sysupgrade*.bin",
}
found = []
for kind, pattern in patterns.items():
    matches = sorted(src.glob(pattern))
    if len(matches) != 1:
        raise SystemExit(f"expected exactly one {kind} image, found {len(matches)}")
    p = matches[0]
    q = dst / p.name
    shutil.copy2(p, q)
    found.append({
        "type": kind,
        "name": q.name,
        "size": q.stat().st_size,
        "sha256": hashlib.sha256(q.read_bytes()).hexdigest(),
    })

(dst / "images.json").write_text(json.dumps(found, indent=2) + "\n")
(dst / "SHA256SUMS").write_text("".join(f"{x['sha256']}  {x['name']}\n" for x in found))
print(f"images={len(found)} initramfs=1 sysupgrade=1")
