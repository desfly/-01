#!/usr/bin/env python3
import argparse
import hashlib
import json
import pathlib
import subprocess
import sys

from stock_firmware import DumpView


def h(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_json(command: list[str]) -> tuple[int, dict, str]:
    proc = subprocess.run(command, capture_output=True, text=True)
    try:
        parsed = json.loads(proc.stdout)
    except json.JSONDecodeError:
        parsed = {}
    return proc.returncode, parsed, proc.stdout + proc.stderr


def sanitize_private_values(value):
    """Remove device-specific MAC values from distributable release reports."""
    if isinstance(value, dict):
        out = {}
        for key, item in value.items():
            if key == "base_mac":
                out["base_mac_valid"] = bool(item)
                out["base_mac_masked"] = "device-specific (redacted)"
            elif key == "file" and isinstance(item, str):
                out[key] = pathlib.Path(item).name
            else:
                out[key] = sanitize_private_values(item)
        return out
    if isinstance(value, list):
        return [sanitize_private_values(item) for item in value]
    return value


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parents[1])
    ap.add_argument("--stock", type=pathlib.Path)
    ap.add_argument("--uboot", type=pathlib.Path)
    ap.add_argument("--art", type=pathlib.Path)
    ap.add_argument("--dist", type=pathlib.Path)
    ap.add_argument("--image-verification", type=pathlib.Path)
    ap.add_argument("--ram-boot-pass", action="store_true")
    ap.add_argument("--physical-print-pass", action="store_true")
    ap.add_argument("--out", type=pathlib.Path, required=True)
    args = ap.parse_args()

    blockers = []
    evidence = {}
    validation = subprocess.run(
        [sys.executable, str(args.root / "tools/validate-source-tree.py"), str(args.root)],
        capture_output=True,
        text=True,
    )
    evidence["source_validation"] = {"pass": validation.returncode == 0, "output": validation.stdout + validation.stderr}
    if validation.returncode:
        blockers.append("source_validation_failed")

    stock_kind = None
    if args.stock:
        rc, stock_report, output = run_json([
            sys.executable,
            str(args.root / "tools/verify_stock_dump.py"),
            str(args.stock),
            "--json",
        ])
        stock_kind = stock_report.get("dump_type")
        evidence["stock_dump"] = {
            "pass": rc == 0,
            "kind": stock_kind,
            "sha256": h(args.stock) if args.stock.exists() else None,
            "report": sanitize_private_values(stock_report),
            "output": "verification completed; device-specific values redacted",
        }
        if rc:
            blockers.append("stock_dump_invalid")
    else:
        blockers.append("stock_dump_missing")

    critical_ok = stock_kind == "full-flash"
    if stock_kind == "mtd5":
        if args.uboot and args.art:
            rc, critical_report, output = run_json([
                sys.executable,
                str(args.root / "tools/verify_critical_regions.py"),
                "--uboot", str(args.uboot),
                "--art", str(args.art),
                "--json",
            ])
            critical_ok = rc == 0
            evidence["critical_regions"] = {"pass": critical_ok, "report": critical_report, "output": output}
            if not critical_ok:
                blockers.append("critical_regions_invalid")
        else:
            if not args.uboot:
                blockers.append("uboot_dump_missing")
            if not args.art:
                blockers.append("art_dump_missing")
    elif args.stock and stock_kind is None:
        blockers.append("critical_regions_unresolved")

    images = []
    if args.dist and args.dist.exists():
        for path in sorted(args.dist.glob("*gainstrong_minibox-v1*.bin")):
            images.append({"name": path.name, "size": path.stat().st_size, "sha256": h(path)})
    evidence["images"] = images
    image_verification_pass = False
    if args.image_verification and args.image_verification.is_file():
        try:
            iv = json.loads(args.image_verification.read_text())
            image_verification_pass = bool(iv.get("pass"))
            evidence["image_verification"] = iv
        except (OSError, json.JSONDecodeError) as exc:
            evidence["image_verification"] = {"pass": False, "error": str(exc)}
    elif images:
        evidence["image_verification"] = {"pass": False, "error": "verification_report_missing"}
    names = " ".join(item["name"] for item in images)
    if "initramfs" not in names:
        blockers.append("initramfs_image_missing")
    if "sysupgrade" not in names:
        blockers.append("sysupgrade_image_missing")
    if images and not image_verification_pass:
        blockers.append("candidate_image_verification_failed")
    if not args.ram_boot_pass:
        blockers.append("ram_boot_not_confirmed")
    if not args.physical_print_pass:
        blockers.append("physical_libusb_print_not_confirmed")

    blockers = list(dict.fromkeys(blockers))
    level = "FLASH_READY" if not blockers else (
        "RAM_BOOT_PASS" if args.ram_boot_pass else (
            "IMAGE_BUILT" if images else (
                "FULL_STOCK_FLASH_VERIFIED" if stock_kind == "full-flash" else
                "STOCK_MTD5_VERIFIED" if stock_kind == "mtd5" else
                "SOURCE_READY"
            )
        )
    )
    result = {
        "build": "Build-0104",
        "level": level,
        "flash_allowed": not blockers,
        "blockers": blockers,
        "evidence": evidence,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if not blockers else 10)


if __name__ == "__main__":
    main()
