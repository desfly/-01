#!/usr/bin/env python3
"""Read-only verifier for MiniBox OpenWrt candidate images.

This is intentionally conservative. It validates the TP-Link v1 container,
MiniBox HWID, size limits, LZMA kernel payload, appended MiniBox DTB identity,
and sysupgrade metadata before an image can advance to RAM-boot testing.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import lzma
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from stock_firmware import EXPECTED_HWID, FIRMWARE_PARTITION_SIZE, TPLINK_HEADER_SIZE, TplinkHeader

BOARD_ID = b"gainstrong,minibox-v1"
IMAGE_LIMIT = FIRMWARE_PARTITION_SIZE


def sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def kernel_payload(data: bytes, header: TplinkHeader) -> bytes:
    begin = header.kernel_offset
    end = begin + header.kernel_length
    if begin < TPLINK_HEADER_SIZE or end > len(data) or header.kernel_length <= 0:
        raise ValueError("kernel_bounds_invalid")
    return data[begin:end]


def decompress_lzma_alone(payload: bytes) -> bytes:
    try:
        return lzma.decompress(payload, format=lzma.FORMAT_ALONE)
    except lzma.LZMAError as exc:
        raise ValueError(f"kernel_lzma_invalid:{exc}") from exc


def verify_one(path: pathlib.Path, image_type: str) -> dict:
    data = path.read_bytes()
    checks: dict[str, bool] = {}
    errors: list[str] = []

    checks["nonempty"] = len(data) > TPLINK_HEADER_SIZE
    checks["within_firmware_partition"] = len(data) <= IMAGE_LIMIT
    try:
        header = TplinkHeader.parse(data)
        checks["tplink_header"] = True
        checks["hwid"] = header.hwid == EXPECTED_HWID
        checks["firmware_max_length"] = header.firmware_max_length in (IMAGE_LIMIT, 0x00F80000, 0x01000000)
        payload = kernel_payload(data, header)
        checks["kernel_bounds"] = True
        kernel = decompress_lzma_alone(payload)
        checks["kernel_lzma"] = len(kernel) > 1024 * 1024
        checks["minibox_dtb_identity"] = BOARD_ID in kernel
        header_dict = header.to_dict()
    except Exception as exc:
        header_dict = {}
        errors.append(str(exc))
        checks.setdefault("tplink_header", False)
        checks.setdefault("hwid", False)
        checks.setdefault("firmware_max_length", False)
        checks.setdefault("kernel_bounds", False)
        checks.setdefault("kernel_lzma", False)
        checks.setdefault("minibox_dtb_identity", False)

    if image_type == "sysupgrade":
        tail = data[-131072:]
        checks["sysupgrade_metadata_board"] = BOARD_ID in tail or b"minibox-v1" in tail
        checks["not_full_flash"] = len(data) != 0x1000000
    else:
        checks["initramfs_name"] = "initramfs" in path.name
        # initramfs must not carry a flash rootfs region.
        if header_dict:
            checks["initramfs_rootfs_not_required"] = header_dict.get("rootfs_length", 0) in (0, 0xFFFFFFFF)
        else:
            checks["initramfs_rootfs_not_required"] = False

    passed = all(checks.values()) and not errors
    return {
        "name": path.name,
        "type": image_type,
        "size": len(data),
        "sha256": sha256(path),
        "pass": passed,
        "checks": checks,
        "errors": errors,
        "header": header_dict,
    }


def pick(dist: pathlib.Path, token: str) -> pathlib.Path | None:
    items = sorted(p for p in dist.glob("*gainstrong_minibox-v1*.bin") if token in p.name)
    return items[0] if len(items) == 1 else None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dist", type=pathlib.Path, required=True)
    ap.add_argument("--out", type=pathlib.Path, required=True)
    args = ap.parse_args()

    initramfs = pick(args.dist, "initramfs")
    sysupgrade = pick(args.dist, "sysupgrade")
    blockers = []
    images = []
    if initramfs is None:
        blockers.append("exactly_one_initramfs_required")
    else:
        images.append(verify_one(initramfs, "initramfs"))
    if sysupgrade is None:
        blockers.append("exactly_one_sysupgrade_required")
    else:
        images.append(verify_one(sysupgrade, "sysupgrade"))
    blockers.extend(f"{item['type']}_verification_failed" for item in images if not item["pass"])

    result = {
        "schema": 1,
        "build": "Build-0104",
        "board": "gainstrong,minibox-v1",
        "hwid": "0x3c000201",
        "firmware_partition_limit": IMAGE_LIMIT,
        "pass": not blockers,
        "blockers": blockers,
        "images": images,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["pass"] else 12)


if __name__ == "__main__":
    main()
