#!/usr/bin/env python3
"""Validate a MiniBox full-flash or mtd5 firmware backup without modifying it."""
import argparse
import json
import pathlib

from stock_firmware import analyze_dump, print_human


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("dump", type=pathlib.Path)
    ap.add_argument("--type", choices=("auto", "full-flash", "mtd5"), default="auto")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    result = analyze_dump(args.dump, args.type)
    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print_human(result)
    raise SystemExit(0 if result.get("pass") else 3)


if __name__ == "__main__":
    main()
