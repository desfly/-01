#!/usr/bin/env python3
"""Validate separately read mtd0 (U-Boot) and mtd4 (ART) backups."""
import argparse
import hashlib
import json
import pathlib

from stock_firmware import ART_SIZE, CAL_OFFSET_IN_ART, CAL_SIZE, MAC_OFFSET_FULL_FLASH, UBOOT_SIZE, valid_mac


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--uboot", type=pathlib.Path, required=True)
    ap.add_argument("--art", type=pathlib.Path, required=True)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    blockers = []
    uboot = args.uboot.read_bytes()
    art = args.art.read_bytes()
    if len(uboot) != UBOOT_SIZE:
        blockers.append("uboot_must_be_exactly_0x20000_bytes")
    if len(art) != ART_SIZE:
        blockers.append("art_must_be_exactly_0x10000_bytes")
    mac = uboot[MAC_OFFSET_FULL_FLASH:MAC_OFFSET_FULL_FLASH + 6] if len(uboot) == UBOOT_SIZE else b""
    cal = art[CAL_OFFSET_IN_ART:CAL_OFFSET_IN_ART + CAL_SIZE] if len(art) == ART_SIZE else b""
    if len(uboot) == UBOOT_SIZE and uboot in (b"\0" * UBOOT_SIZE, b"\xff" * UBOOT_SIZE):
        blockers.append("uboot_is_empty")
    if len(art) == ART_SIZE and art in (b"\0" * ART_SIZE, b"\xff" * ART_SIZE):
        blockers.append("art_is_empty")
    if len(uboot) == UBOOT_SIZE and not valid_mac(mac):
        blockers.append("invalid_base_mac_at_uboot_0x1fc00")
    if len(art) == ART_SIZE and cal in (b"\0" * CAL_SIZE, b"\xff" * CAL_SIZE):
        blockers.append("empty_wifi_calibration_at_art_0x1000")
    result = {
        "pass": not blockers,
        "blockers": blockers,
        "uboot": {"file": str(args.uboot), "size": len(uboot), "sha256": sha(uboot)},
        "art": {"file": str(args.art), "size": len(art), "sha256": sha(art)},
        "base_mac": ":".join(f"{x:02x}" for x in mac) if len(mac) == 6 else None,
        "wifi_calibration_sha256": sha(cal) if len(cal) == CAL_SIZE else None,
    }
    print(json.dumps(result, indent=2) if args.json else "\n".join(f"{k}={v}" for k, v in result.items()))
    raise SystemExit(0 if result["pass"] else 3)


if __name__ == "__main__":
    main()
