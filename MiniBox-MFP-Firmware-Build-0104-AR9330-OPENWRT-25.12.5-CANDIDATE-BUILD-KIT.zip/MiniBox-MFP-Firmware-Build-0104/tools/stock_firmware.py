#!/usr/bin/env python3
"""Read-only parser for Gainstrong MiniBox TP-Link-style firmware dumps.

Supports either:
* a full 16 MiB SPI flash dump (u-boot + firmware + ART), or
* the exact 0xFD0000-byte mtd5 "firmware" partition dump.

The SquashFS reader intentionally implements only the v4/XZ subset needed to
inspect immutable stock configuration files. It never modifies the input.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
import lzma
import math
import pathlib
import struct
from typing import Dict, Iterable, List, Optional, Tuple

FULL_FLASH_SIZE = 0x1000000
FIRMWARE_PARTITION_OFFSET = 0x020000
FIRMWARE_PARTITION_SIZE = 0xFD0000
ART_OFFSET = 0xFF0000
ART_SIZE = 0x010000
UBOOT_SIZE = 0x020000
MAC_OFFSET_FULL_FLASH = 0x01FC00
CAL_OFFSET_IN_ART = 0x1000
CAL_SIZE = 0x440
TPLINK_HEADER_SIZE = 0x200
EXPECTED_HWID = 0x3C000201
SQUASHFS_MAGIC = 0x73717368
SQUASHFS_METADATA_SIZE = 8192
SQUASHFS_INVALID_FRAG = 0xFFFFFFFF
SQUASHFS_COMPRESSED_BIT_BLOCK = 1 << 24
SQUASHFS_COMPRESSED_BIT_METADATA = 1 << 15
JFFS2_MAGIC_LE = b"\x85\x19"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def valid_mac(mac: bytes) -> bool:
    return (
        len(mac) == 6
        and mac not in (b"\x00" * 6, b"\xff" * 6)
        and not bool(mac[0] & 1)
    )


def c_string(raw: bytes) -> str:
    return raw.split(b"\0", 1)[0].decode("ascii", errors="replace")


@dataclasses.dataclass(frozen=True)
class DumpView:
    kind: str
    full: bytes
    firmware: bytes
    firmware_offset_in_source: int
    uboot: Optional[bytes]
    art: Optional[bytes]

    @classmethod
    def from_bytes(cls, data: bytes, requested_kind: str = "auto") -> "DumpView":
        if requested_kind not in {"auto", "full-flash", "mtd5"}:
            raise ValueError("dump_type_must_be_auto_full-flash_or_mtd5")
        inferred = None
        if len(data) == FULL_FLASH_SIZE:
            inferred = "full-flash"
        elif len(data) == FIRMWARE_PARTITION_SIZE:
            inferred = "mtd5"
        if inferred is None:
            raise ValueError(
                f"unsupported_dump_size:{len(data)}:expected_{FULL_FLASH_SIZE}_or_{FIRMWARE_PARTITION_SIZE}"
            )
        if requested_kind != "auto" and requested_kind != inferred:
            raise ValueError(f"dump_type_size_mismatch:requested_{requested_kind}:detected_{inferred}")
        if inferred == "full-flash":
            return cls(
                kind=inferred,
                full=data,
                firmware=data[FIRMWARE_PARTITION_OFFSET:ART_OFFSET],
                firmware_offset_in_source=FIRMWARE_PARTITION_OFFSET,
                uboot=data[:UBOOT_SIZE],
                art=data[ART_OFFSET:ART_OFFSET + ART_SIZE],
            )
        return cls(
            kind=inferred,
            full=data,
            firmware=data,
            firmware_offset_in_source=0,
            uboot=None,
            art=None,
        )


@dataclasses.dataclass(frozen=True)
class TplinkHeader:
    version_raw_be: int
    version_le: int
    vendor: str
    fw_version: str
    hwid: int
    hw_revision: int
    region: int
    md5sum1: str
    kernel_load_address: int
    kernel_entry_point: int
    firmware_max_length: int
    kernel_offset: int
    kernel_length: int
    rootfs_offset_field: int
    rootfs_length: int
    bootloader_offset: int
    bootloader_length: int

    @classmethod
    def parse(cls, firmware: bytes) -> "TplinkHeader":
        if len(firmware) < TPLINK_HEADER_SIZE:
            raise ValueError("firmware_too_short_for_tplink_header")
        # This vendor image stores the first version word in the historical
        # little-endian form, while numeric address/length fields are big-endian.
        return cls(
            version_raw_be=struct.unpack_from(">I", firmware, 0x00)[0],
            version_le=struct.unpack_from("<I", firmware, 0x00)[0],
            vendor=c_string(firmware[0x04:0x1C]),
            fw_version=c_string(firmware[0x1C:0x40]),
            hwid=struct.unpack_from(">I", firmware, 0x40)[0],
            hw_revision=struct.unpack_from(">I", firmware, 0x44)[0],
            region=struct.unpack_from(">I", firmware, 0x48)[0],
            md5sum1=firmware[0x4C:0x5C].hex(),
            kernel_load_address=struct.unpack_from(">I", firmware, 0x74)[0],
            kernel_entry_point=struct.unpack_from(">I", firmware, 0x78)[0],
            firmware_max_length=struct.unpack_from(">I", firmware, 0x7C)[0],
            kernel_offset=struct.unpack_from(">I", firmware, 0x80)[0],
            kernel_length=struct.unpack_from(">I", firmware, 0x84)[0],
            rootfs_offset_field=struct.unpack_from(">I", firmware, 0x88)[0],
            rootfs_length=struct.unpack_from(">I", firmware, 0x8C)[0],
            bootloader_offset=struct.unpack_from(">I", firmware, 0x90)[0],
            bootloader_length=struct.unpack_from(">I", firmware, 0x94)[0],
        )

    @property
    def actual_rootfs_offset(self) -> int:
        return self.kernel_offset + self.kernel_length

    def to_dict(self) -> dict:
        return dataclasses.asdict(self) | {
            "hwid_hex": f"0x{self.hwid:08x}",
            "kernel_load_address_hex": f"0x{self.kernel_load_address:08x}",
            "kernel_entry_point_hex": f"0x{self.kernel_entry_point:08x}",
            "firmware_max_length_hex": f"0x{self.firmware_max_length:08x}",
            "kernel_offset_hex": f"0x{self.kernel_offset:08x}",
            "kernel_length_hex": f"0x{self.kernel_length:08x}",
            "rootfs_offset_field_hex": f"0x{self.rootfs_offset_field:08x}",
            "actual_rootfs_offset": self.actual_rootfs_offset,
            "actual_rootfs_offset_hex": f"0x{self.actual_rootfs_offset:08x}",
            "rootfs_length_hex": f"0x{self.rootfs_length:08x}",
        }


@dataclasses.dataclass(frozen=True)
class SquashSuper:
    inodes: int
    mkfs_time: int
    block_size: int
    fragments: int
    compression: int
    block_log: int
    flags: int
    no_ids: int
    major: int
    minor: int
    root_inode_ref: int
    bytes_used: int
    id_table_start: int
    xattr_id_table_start: int
    inode_table_start: int
    directory_table_start: int
    fragment_table_start: int
    lookup_table_start: int

    @classmethod
    def parse(cls, image: bytes) -> "SquashSuper":
        if len(image) < 96:
            raise ValueError("squashfs_too_short")
        values = struct.unpack_from("<5I6H8Q", image, 0)
        if values[0] != SQUASHFS_MAGIC:
            raise ValueError("squashfs_magic_missing")
        return cls(*values[1:])

    def to_dict(self) -> dict:
        return dataclasses.asdict(self) | {
            "compression_name": {1: "gzip", 2: "lzma", 3: "lzo", 4: "xz", 5: "lz4", 6: "zstd"}.get(self.compression, "unknown")
        }


@dataclasses.dataclass
class Inode:
    ref: int
    inode_type: int
    mode: int
    uid_index: int
    gid_index: int
    mtime: int
    inode_number: int
    start_block: int = 0
    file_size: int = 0
    fragment: int = SQUASHFS_INVALID_FRAG
    fragment_offset: int = 0
    block_sizes: List[int] = dataclasses.field(default_factory=list)
    directory_offset: int = 0
    symlink: Optional[str] = None


class SquashFS:
    """Minimal read-only SquashFS v4/XZ implementation."""

    def __init__(self, image: bytes):
        self.image = image
        self.super = SquashSuper.parse(image)
        if (self.super.major, self.super.minor) != (4, 0):
            raise ValueError("only_squashfs_v4_supported")
        if self.super.compression != 4:
            raise ValueError("only_squashfs_xz_supported")
        if self.super.bytes_used > len(image):
            raise ValueError("squashfs_bytes_used_exceeds_image")
        self._metadata_cache: Dict[int, Tuple[bytes, int]] = {}
        self._inode_cache: Dict[int, Inode] = {}
        self._fragment_cache: Dict[int, bytes] = {}

    def _decompress_xz(self, raw: bytes, what: str) -> bytes:
        try:
            return lzma.decompress(raw, format=lzma.FORMAT_XZ)
        except lzma.LZMAError as exc:
            raise ValueError(f"xz_decompression_failed:{what}:{exc}") from exc

    def _metadata_block(self, absolute: int) -> Tuple[bytes, int]:
        if absolute in self._metadata_cache:
            return self._metadata_cache[absolute]
        if absolute + 2 > len(self.image):
            raise ValueError("metadata_header_out_of_range")
        header = struct.unpack_from("<H", self.image, absolute)[0]
        stored = header & ~SQUASHFS_COMPRESSED_BIT_METADATA
        uncompressed = bool(header & SQUASHFS_COMPRESSED_BIT_METADATA)
        begin = absolute + 2
        end = begin + stored
        if stored == 0 or end > len(self.image):
            raise ValueError("metadata_payload_out_of_range")
        raw = self.image[begin:end]
        data = raw if uncompressed else self._decompress_xz(raw, "metadata")
        if len(data) > SQUASHFS_METADATA_SIZE:
            raise ValueError("metadata_block_too_large")
        result = (data, end)
        self._metadata_cache[absolute] = result
        return result

    def _metadata_bytes(self, table_start: int, block_offset: int, inner_offset: int, size: int) -> bytes:
        if size == 0:
            return b""
        absolute = table_start + block_offset
        block, next_absolute = self._metadata_block(absolute)
        pos = inner_offset
        output = bytearray()
        while len(output) < size:
            if pos > len(block):
                raise ValueError("metadata_inner_offset_out_of_range")
            take = min(size - len(output), len(block) - pos)
            output.extend(block[pos:pos + take])
            if len(output) == size:
                break
            block, next_absolute = self._metadata_block(next_absolute)
            pos = 0
        return bytes(output)

    def inode(self, ref: int) -> Inode:
        if ref in self._inode_cache:
            return self._inode_cache[ref]
        block_offset = ref >> 16
        inner = ref & 0xFFFF
        base = self._metadata_bytes(self.super.inode_table_start, block_offset, inner, 16)
        inode_type, mode, uid, gid, mtime, number = struct.unpack("<4H2I", base)
        inode = Inode(ref, inode_type, mode, uid, gid, mtime, number)

        if inode_type == 1:  # basic directory
            tail = self._metadata_bytes(self.super.inode_table_start, block_offset, inner + 16, 16)
            start_block, _nlink, file_size, offset, _parent = struct.unpack("<IIHHI", tail)
            inode.start_block = start_block
            inode.file_size = file_size
            inode.directory_offset = offset
        elif inode_type == 8:  # extended directory
            tail = self._metadata_bytes(self.super.inode_table_start, block_offset, inner + 16, 24)
            _nlink, file_size, start_block, _parent, _i_count, offset, _xattr = struct.unpack("<4I2HI", tail)
            inode.start_block = start_block
            inode.file_size = file_size
            inode.directory_offset = offset
        elif inode_type == 2:  # basic file
            tail = self._metadata_bytes(self.super.inode_table_start, block_offset, inner + 16, 16)
            start_block, fragment, frag_offset, file_size = struct.unpack("<4I", tail)
            inode.start_block = start_block
            inode.fragment = fragment
            inode.fragment_offset = frag_offset
            inode.file_size = file_size
            full_blocks = file_size // self.super.block_size
            if fragment == SQUASHFS_INVALID_FRAG and file_size % self.super.block_size:
                full_blocks += 1
            if full_blocks:
                raw = self._metadata_bytes(self.super.inode_table_start, block_offset, inner + 32, full_blocks * 4)
                inode.block_sizes = list(struct.unpack(f"<{full_blocks}I", raw))
        elif inode_type == 9:  # extended file
            tail = self._metadata_bytes(self.super.inode_table_start, block_offset, inner + 16, 40)
            start_block, file_size, _sparse, _nlink, fragment, frag_offset, _xattr = struct.unpack("<3Q4I", tail)
            inode.start_block = start_block
            inode.fragment = fragment
            inode.fragment_offset = frag_offset
            inode.file_size = file_size
            full_blocks = file_size // self.super.block_size
            if fragment == SQUASHFS_INVALID_FRAG and file_size % self.super.block_size:
                full_blocks += 1
            if full_blocks:
                raw = self._metadata_bytes(self.super.inode_table_start, block_offset, inner + 56, full_blocks * 4)
                inode.block_sizes = list(struct.unpack(f"<{full_blocks}I", raw))
        elif inode_type in (3, 10):  # symlink / extended symlink
            tail = self._metadata_bytes(self.super.inode_table_start, block_offset, inner + 16, 8)
            _nlink, symlink_size = struct.unpack("<II", tail)
            target = self._metadata_bytes(self.super.inode_table_start, block_offset, inner + 24, symlink_size)
            inode.file_size = symlink_size
            inode.symlink = target.decode("utf-8", errors="replace")
        self._inode_cache[ref] = inode
        return inode

    def directory(self, inode: Inode) -> List[Tuple[str, int, int]]:
        if inode.inode_type not in (1, 8):
            raise ValueError("inode_is_not_directory")
        # file_size includes a historical 3-byte directory terminator adjustment.
        remaining = max(0, inode.file_size - 3)
        raw = self._metadata_bytes(
            self.super.directory_table_start,
            inode.start_block,
            inode.directory_offset,
            remaining,
        )
        pos = 0
        entries: List[Tuple[str, int, int]] = []
        while pos + 12 <= len(raw):
            count, start_block, inode_base = struct.unpack_from("<III", raw, pos)
            pos += 12
            count += 1
            for _ in range(count):
                if pos + 8 > len(raw):
                    raise ValueError("directory_entry_header_truncated")
                offset, inode_delta, inode_type, name_size = struct.unpack_from("<HHHH", raw, pos)
                pos += 8
                name_len = name_size + 1
                if pos + name_len > len(raw):
                    raise ValueError("directory_entry_name_truncated")
                name = raw[pos:pos + name_len].decode("utf-8", errors="replace")
                pos += name_len
                inode_ref = (start_block << 16) | offset
                entries.append((name, inode_ref, inode_type))
        return entries

    def walk(self) -> Dict[str, Inode]:
        output: Dict[str, Inode] = {"/": self.inode(self.super.root_inode_ref)}
        stack = [("/", output["/"])]
        visited = set()
        while stack:
            path, inode = stack.pop()
            if inode.ref in visited:
                continue
            visited.add(inode.ref)
            for name, ref, _typ in self.directory(inode):
                child_path = (path.rstrip("/") + "/" + name) if path != "/" else "/" + name
                child = self.inode(ref)
                output[child_path] = child
                if child.inode_type in (1, 8):
                    stack.append((child_path, child))
        return output

    def _read_data_block(self, offset: int, size_word: int, expected_max: int) -> Tuple[bytes, int]:
        stored = size_word & ~SQUASHFS_COMPRESSED_BIT_BLOCK
        uncompressed = bool(size_word & SQUASHFS_COMPRESSED_BIT_BLOCK)
        if stored == 0:
            return b"\0" * expected_max, offset
        end = offset + stored
        if end > len(self.image):
            raise ValueError("file_data_block_out_of_range")
        raw = self.image[offset:end]
        data = raw if uncompressed else self._decompress_xz(raw, "file-data")
        if len(data) > expected_max:
            raise ValueError("file_data_block_too_large")
        return data, end

    def _fragment_entry(self, index: int) -> Tuple[int, int]:
        if index >= self.super.fragments:
            raise ValueError("fragment_index_out_of_range")
        entries_per_metadata = SQUASHFS_METADATA_SIZE // 16
        table_index = index // entries_per_metadata
        entry_index = index % entries_per_metadata
        index_count = math.ceil(self.super.fragments / entries_per_metadata)
        if table_index >= index_count:
            raise ValueError("fragment_table_index_out_of_range")
        ptr_off = self.super.fragment_table_start + table_index * 8
        metadata_abs = struct.unpack_from("<Q", self.image, ptr_off)[0]
        block, _next = self._metadata_block(metadata_abs)
        off = entry_index * 16
        if off + 16 > len(block):
            raise ValueError("fragment_entry_truncated")
        start, size_word, _unused = struct.unpack_from("<QII", block, off)
        return start, size_word

    def _fragment_block(self, index: int) -> bytes:
        if index in self._fragment_cache:
            return self._fragment_cache[index]
        start, size_word = self._fragment_entry(index)
        data, _ = self._read_data_block(start, size_word, self.super.block_size)
        self._fragment_cache[index] = data
        return data

    def read_file(self, inode: Inode) -> bytes:
        if inode.inode_type in (3, 10):
            return (inode.symlink or "").encode()
        if inode.inode_type not in (2, 9):
            raise ValueError("inode_is_not_regular_file")
        remaining = inode.file_size
        output = bytearray()
        offset = inode.start_block
        for size_word in inode.block_sizes:
            want = min(remaining, self.super.block_size)
            block, offset = self._read_data_block(offset, size_word, self.super.block_size)
            output.extend(block[:want])
            remaining -= want
        if remaining:
            if inode.fragment == SQUASHFS_INVALID_FRAG:
                raise ValueError("file_tail_missing_fragment")
            fragment = self._fragment_block(inode.fragment)
            begin = inode.fragment_offset
            end = begin + remaining
            if end > len(fragment):
                raise ValueError("file_fragment_out_of_range")
            output.extend(fragment[begin:end])
            remaining = 0
        if len(output) != inode.file_size:
            raise ValueError("file_size_mismatch")
        return bytes(output)

    def read_path(self, path: str) -> bytes:
        nodes = self.walk()
        if path not in nodes:
            raise FileNotFoundError(path)
        return self.read_file(nodes[path])


def analyze_dump(path: pathlib.Path, requested_kind: str = "auto", extract_paths: Iterable[str] = ()) -> dict:
    data = path.read_bytes()
    blockers: List[str] = []
    warnings: List[str] = []
    checks: Dict[str, bool] = {}
    extracted: Dict[str, dict] = {}

    try:
        view = DumpView.from_bytes(data, requested_kind)
    except ValueError as exc:
        return {
            "file": str(path),
            "size": len(data),
            "sha256": sha256_bytes(data),
            "pass": False,
            "blockers": [str(exc)],
        }

    header = TplinkHeader.parse(view.firmware)
    checks["tplink_vendor_openwrt"] = header.vendor == "OpenWrt"
    checks["tplink_hwid_minibox"] = header.hwid == EXPECTED_HWID
    checks["kernel_offset_is_header_size"] = header.kernel_offset == TPLINK_HEADER_SIZE
    checks["kernel_range_in_firmware"] = (
        header.kernel_offset >= TPLINK_HEADER_SIZE
        and header.kernel_length > 0
        and header.kernel_offset + header.kernel_length <= len(view.firmware)
    )
    checks["rootfs_range_in_firmware"] = (
        header.actual_rootfs_offset >= header.kernel_offset + header.kernel_length
        and header.rootfs_length > 0
        and header.actual_rootfs_offset + header.rootfs_length <= len(view.firmware)
    )
    checks["firmware_partition_size_exact"] = len(view.firmware) == FIRMWARE_PARTITION_SIZE
    checks["header_firmware_max_matches_16mlzma"] = header.firmware_max_length == 0xF80000

    kernel = b""
    kernel_decompressed = b""
    rootfs = b""
    squash = None
    nodes: Dict[str, Inode] = {}
    overlay_start = None
    overlay = b""

    if checks["kernel_range_in_firmware"]:
        kernel = view.firmware[header.kernel_offset:header.kernel_offset + header.kernel_length]
        try:
            kernel_decompressed = lzma.decompress(kernel, format=lzma.FORMAT_AUTO)
            checks["kernel_lzma_decompresses"] = len(kernel_decompressed) > 0
        except lzma.LZMAError as exc:
            checks["kernel_lzma_decompresses"] = False
            warnings.append(f"kernel_lzma_error:{exc}")
    else:
        checks["kernel_lzma_decompresses"] = False

    if checks["rootfs_range_in_firmware"]:
        rootfs = view.firmware[header.actual_rootfs_offset:header.actual_rootfs_offset + header.rootfs_length]
        checks["rootfs_has_squashfs_magic"] = rootfs[:4] == b"hsqs"
        if checks["rootfs_has_squashfs_magic"]:
            try:
                squash = SquashFS(rootfs)
                checks["squashfs_bytes_used_matches_header"] = squash.super.bytes_used == header.rootfs_length
                nodes = squash.walk()
                checks["squashfs_tree_readable"] = len(nodes) == squash.super.inodes
                for wanted in extract_paths:
                    try:
                        content = squash.read_path(wanted)
                        extracted[wanted] = {
                            "size": len(content),
                            "sha256": sha256_bytes(content),
                            "text": content.decode("utf-8", errors="replace") if len(content) <= 128 * 1024 else None,
                        }
                    except (FileNotFoundError, ValueError) as exc:
                        extracted[wanted] = {"error": str(exc)}
            except ValueError as exc:
                checks["squashfs_bytes_used_matches_header"] = False
                checks["squashfs_tree_readable"] = False
                warnings.append(f"squashfs_error:{exc}")
        else:
            checks["squashfs_bytes_used_matches_header"] = False
            checks["squashfs_tree_readable"] = False
    else:
        checks["rootfs_has_squashfs_magic"] = False
        checks["squashfs_bytes_used_matches_header"] = False
        checks["squashfs_tree_readable"] = False

    if rootfs:
        rootfs_end = header.actual_rootfs_offset + header.rootfs_length
        overlay_start = (rootfs_end + 0xFFFF) & ~0xFFFF
        if overlay_start < len(view.firmware):
            overlay = view.firmware[overlay_start:]
            checks["overlay_is_eraseblock_aligned"] = overlay_start % 0x10000 == 0
            checks["overlay_contains_jffs2_nodes"] = overlay.count(JFFS2_MAGIC_LE) > 0
        else:
            checks["overlay_is_eraseblock_aligned"] = False
            checks["overlay_contains_jffs2_nodes"] = False

    critical = {}
    if view.kind == "full-flash":
        assert view.uboot is not None and view.art is not None
        mac = data[MAC_OFFSET_FULL_FLASH:MAC_OFFSET_FULL_FLASH + 6]
        cal = view.art[CAL_OFFSET_IN_ART:CAL_OFFSET_IN_ART + CAL_SIZE]
        checks["u_boot_present"] = view.uboot not in (b"\0" * UBOOT_SIZE, b"\xff" * UBOOT_SIZE)
        checks["art_present"] = view.art not in (b"\0" * ART_SIZE, b"\xff" * ART_SIZE)
        checks["base_mac_valid"] = valid_mac(mac)
        checks["wifi_calibration_nonempty"] = cal not in (b"\0" * CAL_SIZE, b"\xff" * CAL_SIZE)
        critical = {
            "base_mac": ":".join(f"{x:02x}" for x in mac),
            "u_boot_sha256": sha256_bytes(view.uboot),
            "art_sha256": sha256_bytes(view.art),
            "wifi_calibration_sha256": sha256_bytes(cal),
        }
    else:
        warnings.extend(["u_boot_not_present_in_mtd5_dump", "art_not_present_in_mtd5_dump", "base_mac_not_present_in_mtd5_dump"])

    for name, ok in checks.items():
        if not ok and name not in {"u_boot_present", "art_present", "base_mac_valid", "wifi_calibration_nonempty"}:
            blockers.append(name)
    if view.kind == "full-flash":
        for required in ("u_boot_present", "art_present", "base_mac_valid", "wifi_calibration_nonempty"):
            if not checks.get(required, False):
                blockers.append(required)

    sections = {
        "kernel": {
            "offset": header.kernel_offset,
            "offset_hex": f"0x{header.kernel_offset:08x}",
            "stored_size": len(kernel),
            "sha256": sha256_bytes(kernel) if kernel else None,
            "decompressed_size": len(kernel_decompressed),
            "decompressed_sha256": sha256_bytes(kernel_decompressed) if kernel_decompressed else None,
        },
        "rootfs": {
            "offset": header.actual_rootfs_offset,
            "offset_hex": f"0x{header.actual_rootfs_offset:08x}",
            "stored_size": len(rootfs),
            "sha256": sha256_bytes(rootfs) if rootfs else None,
            "squashfs": squash.super.to_dict() if squash else None,
            "tree_entries": len(nodes),
        },
        "overlay": {
            "offset": overlay_start,
            "offset_hex": f"0x{overlay_start:08x}" if overlay_start is not None else None,
            "stored_size": len(overlay),
            "sha256": sha256_bytes(overlay) if overlay else None,
            "jffs2_magic_count": overlay.count(JFFS2_MAGIC_LE) if overlay else 0,
        },
    }

    return {
        "schema": 1,
        "file": str(path),
        "dump_type": view.kind,
        "size": len(data),
        "size_hex": f"0x{len(data):x}",
        "sha256": sha256_bytes(data),
        "pass": not blockers,
        "blockers": blockers,
        "warnings": warnings,
        "checks": checks,
        "header": header.to_dict(),
        "sections": sections,
        "critical_regions": critical,
        "extracted_files": extracted,
    }


def print_human(result: dict) -> None:
    print(f"file={result.get('file')}")
    print(f"dump_type={result.get('dump_type', 'unknown')}")
    print(f"size={result.get('size')} ({result.get('size_hex', '')})")
    print(f"sha256={result.get('sha256')}")
    if "header" in result:
        h = result["header"]
        print(f"vendor={h['vendor']}")
        print(f"firmware_version={h['fw_version']}")
        print(f"hwid={h['hwid_hex']}")
        print(f"kernel={h['kernel_offset_hex']}+{h['kernel_length_hex']}")
        print(f"rootfs_actual={h['actual_rootfs_offset_hex']}+{h['rootfs_length_hex']}")
    for name, passed in result.get("checks", {}).items():
        print(f"check.{name}={'PASS' if passed else 'FAIL'}")
    for warning in result.get("warnings", []):
        print(f"warning={warning}")
    for blocker in result.get("blockers", []):
        print(f"blocker={blocker}")
    print(f"pass={'true' if result.get('pass') else 'false'}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("dump", type=pathlib.Path)
    parser.add_argument("--type", choices=("auto", "full-flash", "mtd5"), default="auto")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    report = analyze_dump(args.dump, args.type)
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        print_human(report)
    raise SystemExit(0 if report.get("pass") else 3)
