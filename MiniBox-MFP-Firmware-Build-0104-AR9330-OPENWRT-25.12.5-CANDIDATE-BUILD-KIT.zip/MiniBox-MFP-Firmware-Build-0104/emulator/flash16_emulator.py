#!/usr/bin/env python3
from dataclasses import dataclass

FLASH_SIZE=0x1000000
UBOOT_OFF=0x000000
UBOOT_SIZE=0x020000
FIRMWARE_OFF=0x020000
FIRMWARE_SIZE=0xfd0000
ART_OFF=0xff0000
ART_SIZE=0x010000

@dataclass
class FlashResult:
    accepted: bool
    reason: str

class Flash16:
    def __init__(self):
        self.data=bytearray(b'\xff'*FLASH_SIZE)
        self.data[0:8]=b'UBOOT101'
        self.data[ART_OFF:ART_OFF+8]=b'ART0101!'
        self.data[0x1fc00:0x1fc06]=bytes.fromhex('02 11 22 33 44 55')
        self.data[ART_OFF+0x1000:ART_OFF+0x1440]=bytes((i*17+3)&255 for i in range(0x440))
    def apply_sysupgrade(self,image:bytes)->FlashResult:
        if len(image)==0: return FlashResult(False,'empty')
        if len(image)>FIRMWARE_SIZE: return FlashResult(False,'firmware_partition_overflow')
        before_uboot=bytes(self.data[:UBOOT_SIZE]); before_art=bytes(self.data[ART_OFF:])
        self.data[FIRMWARE_OFF:FIRMWARE_OFF+FIRMWARE_SIZE]=b'\xff'*FIRMWARE_SIZE
        self.data[FIRMWARE_OFF:FIRMWARE_OFF+len(image)]=image
        if bytes(self.data[:UBOOT_SIZE])!=before_uboot: return FlashResult(False,'uboot_changed')
        if bytes(self.data[ART_OFF:])!=before_art: return FlashResult(False,'art_changed')
        return FlashResult(True,'ok')
