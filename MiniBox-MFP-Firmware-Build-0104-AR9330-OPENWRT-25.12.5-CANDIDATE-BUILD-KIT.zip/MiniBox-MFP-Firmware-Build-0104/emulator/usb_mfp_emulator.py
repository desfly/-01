#!/usr/bin/env python3
import argparse, binascii, socket, pathlib

def recv_line(conn, limit=256):
    data=b''
    while not data.endswith(b'\n'):
        b=conn.recv(1)
        if not b or len(data)>=limit: raise RuntimeError('bad header')
        data+=b
    return data.decode().strip()

def run(host, port, outdir, once=False):
    outdir.mkdir(parents=True, exist_ok=True)
    with socket.socket() as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port)); s.listen(4)
        actual=s.getsockname()[1]
        print(f'LISTEN {actual}', flush=True)
        while True:
            conn,_=s.accept()
            with conn:
                parts=recv_line(conn).split()
                if len(parts)!=3 or parts[0]!='PRINT': raise RuntimeError('protocol')
                size=int(parts[1]); expected=int(parts[2],16)
                data=bytearray()
                while len(data)<size:
                    chunk=conn.recv(min(65536,size-len(data)))
                    if not chunk: break
                    data.extend(chunk)
                crc=binascii.crc32(data)&0xffffffff
                if len(data)!=size or crc!=expected:
                    conn.sendall(f'ERR {len(data)} {crc:08x}\n'.encode())
                else:
                    p=outdir/f'job-{crc:08x}.pcl'; p.write_bytes(data)
                    conn.sendall(f'OK {crc:08x}\n'.encode())
            if once: break

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--host',default='127.0.0.1'); ap.add_argument('--port',type=int,default=0); ap.add_argument('--outdir',type=pathlib.Path,required=True); ap.add_argument('--once',action='store_true'); a=ap.parse_args(); run(a.host,a.port,a.outdir,a.once)
if __name__=='__main__': main()
