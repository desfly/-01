define Device/gainstrong_minibox-v1
  $(Device/tplink-16mlzma)
  SOC := ar9330
  DEVICE_VENDOR := Gainstrong
  DEVICE_MODEL := MiniBox
  DEVICE_VARIANT := V1.0
  DEVICE_PACKAGES := kmod-usb-core kmod-usb-chipidea2 libusb-1.0 wpad-basic-mbedtls minibox-mfp
  TPLINK_HWID := 0x3c000201
  SUPPORTED_DEVICES += minibox-v1
endef
TARGET_DEVICES += gainstrong_minibox-v1
