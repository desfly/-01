# Upstream sources and board evidence

- OpenWrt source: official repository tag `v25.12.5`.
- OpenWrt GitHub repository: read-only mirror/fallback for CI cloning.
- AR9330 base DTS: `target/linux/ath79/dts/ar9330.dtsi`.
- AR9330 USB/Ethernet reference board: `ar9330_glinet_gl-ar150.dts`.
- TP-Link 16-MiB recipe: `target/linux/ath79/image/common-tp-link.mk`,
  template `tplink-16mlzma`, `IMAGE_SIZE := 16192k`.
- Historical MiniBox V1 board patch: OpenWrt-devel, September 2015;
  confirms HWID, GPIO, flash MAC offset, ART calibration offset, USB host and
  MAC increments.
- Device-owned evidence: verified mtd0 U-Boot, mtd5 stock firmware and mtd4 ART.

The historical patch is hardware evidence, not code copied into the candidate.
The current board port translates those facts to OpenWrt ath79/nvmem syntax.
