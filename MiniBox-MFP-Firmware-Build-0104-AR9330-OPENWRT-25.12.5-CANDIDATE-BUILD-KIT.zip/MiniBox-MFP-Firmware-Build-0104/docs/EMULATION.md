# Емуляційна стратегія

QEMU не моделює точну плату Gainstrong MiniBox V1.0: AR933x switch, ART,
GPIO, vendor TP-Link image header і реальний USB MFP не відтворюються як одна
готова machine. Тому використано два детерміновані емулятори:

1. `usb_mfp_emulator.py` — приймає print job, перевіряє довжину/CRC32,
   зберігає PCL і повертає підтвердження.
2. `flash16_emulator.py` — моделює 16-MiB SPI NOR, захищає U-Boot/ART,
   перевіряє межі firmware partition і відмовляє при переповненні.

Додатково C-код `miniboxd` компілюється на host та виконує print transaction
через TCP transport. Наступний апаратний рівень — initramfs RAM-boot.
