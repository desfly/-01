# Read-only backup of mtd0 and mtd4

Run on the existing MiniBox through SSH. These commands only read flash; they
do not erase or write anything.

```sh
set -e
dd if=/dev/mtd0 of=/tmp/minibox-mtd0-uboot.bin bs=64k
sync
dd if=/dev/mtd4 of=/tmp/minibox-mtd4-art.bin bs=64k
sync
sha256sum /tmp/minibox-mtd0-uboot.bin /tmp/minibox-mtd4-art.bin
ls -l /tmp/minibox-mtd0-uboot.bin /tmp/minibox-mtd4-art.bin
```

Expected exact sizes:

- mtd0 U-Boot: `131072` bytes (`0x20000`)
- mtd4 ART: `65536` bytes (`0x10000`)

Copy both files to the PC with SCP and upload them for validation. Never write,
truncate, edit, or run `mtd write` against either partition.
