# Збірка на Ubuntu / Debian

Потрібна 64-бітна Linux-система з приблизно 25–35 GB вільного місця.

```sh
sudo apt update
sudo apt install -y build-essential clang flex bison g++ gawk gcc-multilib gettext git   libncurses-dev libssl-dev libelf-dev libzstd-dev python3 python3-setuptools rsync unzip zlib1g-dev   file wget curl subversion swig time xsltproc zstd

unzip MiniBox-MFP-Firmware-Build-0104-SOURCE.zip
cd MiniBox-MFP-Firmware-Build-0104
./scripts/run-host-validation.sh
./scripts/bootstrap-openwrt.sh
./scripts/build-openwrt.sh
```

Збірка використовує точний тег OpenWrt `v25.12.5`. Зовнішні feeds за замовчуванням не оновлюються, бо цей профіль використовує лише core packages. Для експериментального ввімкнення feeds: `UPDATE_FEEDS=1 ./scripts/bootstrap-openwrt.sh`.

Після збірки:

```sh
python3 tools/collect-images.py openwrt-src/bin/targets/ath79/generic dist
python3 tools/generate-release-gate.py --root . --stock firmware.bin --dist dist   --out reports/release-gate.json
```

До фізичного RAM-boot `flash_allowed` має залишатися `false`.
