# Build real candidate images with GitHub Actions

Build-0104 intentionally contains no prebuilt firmware. The two `.bin` files must
be produced by the pinned OpenWrt v25.12.5 toolchain and must pass the bundled
image verifier.

1. Create a **private** empty GitHub repository.
2. Upload the complete contents of this source tree (not the outer ZIP folder).
3. Open **Actions → build-minibox-firmware → Run workflow**.
4. After both jobs are green, download artifact
   `minibox-v1-openwrt-25.12.5-build0104`.
5. The artifact must contain exactly:
   - one `*initramfs-kernel.bin`;
   - one `*squashfs-sysupgrade.bin`;
   - `SHA256SUMS`;
   - `IMAGE-VERIFICATION.json` with `"pass": true`;
   - `release-gate.json` with `level: IMAGE_BUILT` and `flash_allowed: false`.

Do **not** sysupgrade yet. The initramfs image is the next artifact for serial
U-Boot RAM-boot. Only after Ethernet, Wi-Fi calibration, USB enumeration, and a
physical libusb print pass may the sysupgrade image be considered.
