# Відомі обмеження Build-0104

1. **У цьому архіві немає готового `.bin`.** Оригінальний mtd5 перевірено, але локальний контейнер не має DNS і повного OpenWrt toolchain, тому image build тут не підміняється вигаданим результатом.
2. **mtd5 — не повний flash dump.** Він не містить mtd0 U-Boot і mtd4 ART. До будь-якого запису flash потрібні окремі точні backup-файли 0x20000 і 0x10000 байт.
3. **Точний AR9330/AR9331 MiniBox не має повної моделі в QEMU.** Host-емулятори перевіряють SPI-layout, USB descriptor selection, TCP/9100, stock parser та release gate; GPIO, Ethernet PHY, Wi-Fi calibration і USB power перевіряються RAM-boot на реальному MiniBox.
4. **Сканування заблоковане свідомо.** HP LaserJet M1522n вимагає окремий закритий HP plug-in. Він не включений і не підміняється заглушкою.
5. **Cancel є best-effort.** Одна libusb print transaction виконується синхронно; cancel перевіряється між USB chunks, але не є миттєвим hard-abort.
6. **Flash заборонений**, доки `reports/release-gate.json` не має `flash_allowed: true` після валідації mtd0/mtd4, image build, RAM-boot і фізичного друку.
