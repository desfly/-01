# Gainstrong MiniBox V1.0 — verified board facts

| Parameter | Value | Evidence |
|---|---:|---|
| SoC | Atheros AR9330 rev 1 | stock kernel `/proc/cpuinfo` |
| RAM | 64 MiB | device data |
| SPI NOR | 16 MiB | `/proc/mtd` + full reconstruction |
| System LED | GPIO 1, active low | historical board port |
| Reset key | GPIO 11, active high | historical board port |
| Base MAC cell | U-Boot offset `0x1fc00` | historical port + verified mtd0 |
| Wi-Fi calibration | ART offset `0x1000`, size `0x440` | historical port + verified mtd4 |
| Firmware partition | `0x020000..0xFF0000`, size `0xFD0000` | stock layout |
| ART | final `0x10000`, read-only | verified mtd4 |
| USB | AR9330 ChipIdea USB2 host | current OpenWrt DTS + hardware observation |
| Vendor HWID | `0x3c000201` | stock header + historical port |

## Current ath79 candidate mapping

The board now includes `ar9330.dtsi`, not `ar9331.dtsi`.
The AR9330 description exposes:

- `eth0`: PHY4 path, treated as WAN candidate;
- `eth1`: fixed link to the internal AR7240 switch, treated as LAN;
- `gmac-config`: attached to `eth1`, matching current AR9330 reference DTS files.

The old vendor firmware used different interface numbering (`eth0` LAN and a
vendor `eth2` WAN). Therefore names are not accepted as proof by themselves:
the initramfs RAM-boot checklist validates each physical RJ45 port before flash.

MAC increments remain those from the original board port (`eth0 +1`, `eth1 -1`)
and Wi-Fi uses the base MAC. Their uniqueness and physical-port association are
mandatory RAM-boot checks; sysupgrade remains blocked until then.
