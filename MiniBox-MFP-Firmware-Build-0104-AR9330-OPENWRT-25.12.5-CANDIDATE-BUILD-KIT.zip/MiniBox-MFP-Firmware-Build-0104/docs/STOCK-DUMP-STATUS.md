# Stock firmware evidence — Build-0104

Перевірено на оригінальному `firmware.bin`, прочитаному з `/dev/mtd5`.

- Size: `16580608` bytes (`0xFD0000`)
- SHA-256: `638952b5f34c75acdb69f64071eef3c2e2a51223d145716df4534797068a29c3`
- TP-Link vendor: `OpenWrt`
- Vendor revision: `49971`
- HWID: `0x3c000201`
- Kernel: LZMA, decompresses successfully
- Rootfs: SquashFS 4.0 / XZ, `1125` inodes, fully traversed
- JFFS2 overlay: starts at `0x3c0000`

The stock image is structurally valid as an mtd5 backup. It is not a full
16-MiB SPI flash dump: U-Boot (mtd0) and ART (mtd4) are not present. They must
be read separately and preserved before any flash write.

The mutable JFFS2 overlay was not extracted, so Wi-Fi credentials and other
runtime secrets were not copied into this source archive.
