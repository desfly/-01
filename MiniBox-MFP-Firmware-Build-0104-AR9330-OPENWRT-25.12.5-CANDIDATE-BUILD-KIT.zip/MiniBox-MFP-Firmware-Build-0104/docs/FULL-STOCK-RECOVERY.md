# Device-specific stock recovery image

Build-0104 verified all three physical flash regions and reconstructed an exact
16 MiB stock image locally:

| Region | Offset | Size |
|---|---:|---:|
| U-Boot (`mtd0`) | `0x000000` | `0x020000` |
| Firmware (`mtd5`) | `0x020000` | `0xFD0000` |
| ART (`mtd4`) | `0xFF0000` | `0x010000` |

Verified reconstructed image SHA-256:

`44bfe66afe0cf65c46e8a1c562aceaea2755ce06fdf5d3c1f0f647953b3afef4`

The actual recovery binary is intentionally excluded from this source kit. It
contains device-specific U-Boot data, the base MAC address, and Wi-Fi ART
calibration. It must not be shared or flashed to another MiniBox.

This full-flash image is **not** a sysupgrade image. It is reserved for recovery
using a hardware programmer or a deliberately verified bootloader recovery
procedure. Never write it with `sysupgrade`.
