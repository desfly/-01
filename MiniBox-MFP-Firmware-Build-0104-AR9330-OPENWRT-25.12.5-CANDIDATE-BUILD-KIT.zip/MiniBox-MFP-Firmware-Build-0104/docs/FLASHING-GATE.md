# Flashing gate

## Completed evidence

- [x] original mtd0 U-Boot is exactly `0x20000` and verified;
- [x] original mtd5 firmware is exactly `0xFD0000` and verified;
- [x] original mtd4 ART is exactly `0x10000` and verified;
- [x] base MAC and non-empty Wi-Fi calibration area are verified;
- [x] exact private 16-MiB stock recovery image is reconstructed;
- [x] source, SPI-flash, USB descriptor and transport emulators pass;
- [x] OpenWrt build is pinned to exact tag `v25.12.5`;
- [x] candidate image verifier is included.

## Still required before flash

- [ ] GitHub Actions/OpenWrt toolchain creates one initramfs and one sysupgrade image;
- [ ] `IMAGE-VERIFICATION.json` reports `pass: true`;
- [ ] initramfs is loaded through UART/U-Boot/TFTP without any flash write;
- [ ] UART reaches userspace without panic;
- [ ] physical LAN/WAN ports and unique MAC addresses are confirmed;
- [ ] Wi-Fi starts without calibration errors;
- [ ] USB enumerates HP `03f0:4517`;
- [ ] `usblp` is absent;
- [ ] PCL5e page prints through libusb;
- [ ] power-cycle returns to untouched stock firmware;
- [ ] only then is sysupgrade considered.

## Release levels

- `SOURCE_READY`
- `FULL_STOCK_FLASH_VERIFIED`
- `IMAGE_BUILT`
- `RAM_BOOT_PASS`
- `FLASH_READY`

Build-0104 is currently `FULL_STOCK_FLASH_VERIFIED`; `flash_allowed=false`.
