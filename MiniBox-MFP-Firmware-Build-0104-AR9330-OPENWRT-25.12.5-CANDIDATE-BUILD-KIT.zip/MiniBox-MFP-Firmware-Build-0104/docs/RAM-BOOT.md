# RAM-boot procedure — mandatory before flash

Build-0104 deliberately does not hard-code an arbitrary U-Boot RAM address.
Use the actual values printed by the device bootloader.

## 1. Capture environment over UART

At the U-Boot prompt record:

```text
printenv
help tftpboot
help bootm
```

Keep the complete transcript. Do not issue `erase`, `cp.b`, `sf erase`,
`sf write`, `mtd`, or `saveenv` during RAM validation.

## 2. TFTP-only test

Place the generated `*initramfs-kernel.bin` on the TFTP server. Then use the
bootloader's existing `${loadaddr}`/`${ipaddr}`/`${serverip}` values:

```text
tftpboot ${loadaddr} <exact-initramfs-filename>
bootm ${loadaddr}
```

If `${loadaddr}` is not defined, stop and inspect `printenv`; do not guess.

## 3. Required PASS evidence

- serial console reaches an OpenWrt shell without kernel panic;
- `/proc/mtd` keeps U-Boot and ART separate/read-only;
- Ethernet is reachable at `192.168.55.251`;
- `cat /sys/class/net/*/address` shows valid unique MAC addresses;
- `dmesg` has no ath9k calibration error;
- `lsusb` shows `03f0:4517`;
- `lsmod | grep usblp` is empty;
- `/usr/sbin/miniboxd --selftest` passes;
- a PCL page prints through libusb.

Power-cycle to prove the vendor firmware still boots from flash. Only after
this evidence can the release state move from `IMAGE_BUILT` to `RAM_BOOT_PASS`.
