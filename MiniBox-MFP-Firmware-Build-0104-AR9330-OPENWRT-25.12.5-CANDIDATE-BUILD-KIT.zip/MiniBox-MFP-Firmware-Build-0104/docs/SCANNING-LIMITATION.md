# HP M1522n scanning limitation

HP LaserJet M1522/M1522n scanning через HPLIP вимагає proprietary plug-in.
Build-0104 не містить і не розповсюджує цей файл.

Поведінка до встановлення plug-in:

```json
{"scan":"blocked","reason":"hp_proprietary_plugin_required"}
```

Після отримання plug-in від HP окремий майбутній build має:

1. перевірити його ліцензію та SHA-256;
2. встановити лише локально на пристрій;
3. додати hplip-sane/libsane у flash-size budget;
4. виконати реальне USB scan validation.
