# Build-0104 status

Status: **SOURCE_VERIFIED / IMAGE BUILD RECIPE READY**

Corrections from Build-0103:

- pin corrected to the current stable OpenWrt `v25.12.5` tag after verification against the official release index;
- SoC corrected to `ar9330` and DTS now includes `ar9330.dtsi`;
- `gmac-config` moved to `eth1`, the AR9330 internal switch path;
- modern network mapping fixed as `eth1 = LAN`, `eth0 = WAN candidate`;
- USB host package changed to `kmod-usb-chipidea2`;
- build clone has official-server → GitHub-mirror fallback;
- real candidate images receive TP-Link header/HWID/size/LZMA/DTB/metadata checks;
- release gate cannot become flash-ready from image creation alone.

Local container limitations: no network-resolved OpenWrt source, no OpenWrt MIPS
toolchain, and no QEMU MIPS binary. Host C tests and protocol/flash emulators are
run locally; the pinned GitHub Actions workflow performs the real cross-build.
